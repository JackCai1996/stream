#ifndef QHLISTENSOCKET_H
#define QHLISTENSOCKET_H

#include "QHDataSocket.h"

class QHListenSocket : public QHSocketBase
{
public:
    QHListenSocket();
    ~QHListenSocket();

public:
    bool Listen(unsigned short port);
    QHDataSocket* Accept() const;
};

#endif // QHLISTENSOCKET_H
