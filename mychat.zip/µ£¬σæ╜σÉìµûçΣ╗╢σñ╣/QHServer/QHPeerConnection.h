#ifndef QHPEERCONNECTION_H
#define QHPEERCONNECTION_H

#include "QHDataSocket.h"

#include <queue>
#include <time.h>

static const char* kRequestPaths[] =
{
    "/wait",
    "/sign_out",
    "/message",
};

enum RequestPathIndex {
    kWait,
    kSignOut,
    kMessage,
};

class QHPeerConnection
{
public:
    QHPeerConnection(QHDataSocket* socket);
    ~QHPeerConnection();

public:
    int Id() const;
    const std::string& Name() const;
    bool IsConnected() const;
    void Disconnect();

    bool IsWaitRequest(QHDataSocket* ds) const;
    bool IsTimedOut();
    std::string GetPeerIdHeader() const;
    bool NotifyOtherPeers(const QHPeerConnection& other);
    // Returns a string in the form "name,id,connected\n".
    std::string GetEntry() const;
    void ForwardRequestToPeer(QHDataSocket* ds, QHPeerConnection* peer);
    void Close(QHDataSocket* ds);
    void QueueResponse(const std::string& status,
                       const std::string& content_type,
                       const std::string& extra_headers,
                       const std::string& data);
    void SetWaitSocket(QHDataSocket* ds);

private:
    struct Response
    {
        std::string status, content_type, extra_headers, data;
    };

    QHDataSocket* wait_socket_;
    int id_;
    std::string name_;
    bool connected_;
    time_t timestamp_;

    std::queue<Response> queue_;
    static int s_peer_id_;
};

#endif // QHPEERCONNECTION_H
