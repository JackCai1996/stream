#ifndef QHSOCKETBASE_H
#define QHSOCKETBASE_H

#ifdef WIN32
#include <winsock2.h>
typedef int socklen_t;
typedef SOCKET NativeSocket;
#endif

class QHSocketBase
{
public:
    QHSocketBase();
    QHSocketBase(NativeSocket socket);
    ~QHSocketBase();

    NativeSocket socket() const;
    bool valid() const;

    bool Create();
    void Close();

protected:
    NativeSocket socket_;
};

#endif // QHSOCKETBASE_H
