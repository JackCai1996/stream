#ifndef QHPEERCONNECTIONMANAGER_H
#define QHPEERCONNECTIONMANAGER_H

#include "QHPeerConnection.h"

typedef std::vector<QHPeerConnection*> Peers;

class QHPeerConnectionManager
{
public:
    QHPeerConnectionManager();
    ~QHPeerConnectionManager();

public:
    // Returns true if the request should be treated as a new QHPeerConnection
    // request.  Otherwise the request is not peerconnection related.
    static bool IsNewConnection(const QHDataSocket* ds);
    // Finds a connected peer that's associated with the |ds| socket.
    QHPeerConnection* FindPeer(QHDataSocket* ds) const;
    // Checks if the request has a "peer_id" parameter and if so, looks up the
    // peer for which the request is targeted at.
    QHPeerConnection* FindTargetPeer(const QHDataSocket* ds) const;
    // Adds a new QHPeerConnection instance to the list of connected peers and
    // associates it with the socket.
    bool AddPeer(QHDataSocket* ds);
    // Closes all connections and sends a "shutting down" message to all
    // connected peers.
    void Clear();
    // Called when a socket was determined to be closing by the peer (or if the
    // connection went dead).
    void Close(QHDataSocket* ds);
    void CheckForTimeout();

private:
    // 将peer的状态变化广播给其他peers.
    void BroadcastChangedState(const QHPeerConnection& peer);
    // Builds a simple list of "name,id,connected\n" entries for each peer.
    // 为新peer创建peer列表，该新peer是列表的第一项.
    std::string BuildResponseForNewPeer(const QHPeerConnection& peer);

private:
    Peers peers_;
};

#endif // QHPEERCONNECTIONMANAGER_H
