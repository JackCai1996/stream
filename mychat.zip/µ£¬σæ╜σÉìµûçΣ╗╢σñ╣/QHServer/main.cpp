#include <QCoreApplication>
#include <QDebug>
#include <vector>

#include "QHListenSocket.h"
#include "QHDataSocket.h"
#include "QHPeerConnection.h"
#include "QHPeerConnectionManager.h"

typedef std::vector<QHDataSocket*> SocketArray;

static const size_t kMaxConnections = (FD_SETSIZE - 2);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QHListenSocket listener;

    if (!listener.Listen(8888))
    {
        qDebug()<<"Server listen failed";
        return -1;
    }

    qDebug()<< "Server listen on port 8888";

    QHPeerConnectionManager pcm;
    SocketArray sockets;

    bool quit = false;
    while (!quit)
    {
        fd_set socket_set;
        FD_ZERO(&socket_set);
        if (listener.valid())
        {
            FD_SET(listener.socket(), &socket_set);
        }

        for (SocketArray::iterator i = sockets.begin(); i != sockets.end(); ++i)
        {
            FD_SET((*i)->socket(), &socket_set);
        }

        struct timeval timeout = {10, 0};
        if (select(FD_SETSIZE, &socket_set, nullptr, nullptr, &timeout) == SOCKET_ERROR)
        {
            qDebug()<<"Server select failed";
            break;
        }

        for (SocketArray::iterator i = sockets.begin(); i != sockets.end(); ++i)
        {
            QHDataSocket* ds = *i;
            bool need_close_socket = true;
            if (FD_ISSET(ds->socket(), &socket_set))
            {
                // 当接收到的数据长度为0时，需关闭该socket，即need_close_socket返回true.
                if (ds->ReceiveData(&need_close_socket) && ds->request_received())
                {
                    QHPeerConnection* peer = pcm.FindPeer(ds);
                    if (peer || QHPeerConnectionManager::IsNewConnection(ds))
                    {
                        if (!peer)
                        {
                            if (ds->PathEquals("/sign_in"))
                            {
                                pcm.AddPeer(ds);
                            }
                            else
                            {
                                qDebug()<<"No peer found for: "<<ds->request_path().c_str();
                                ds->Send("500 Error", true, "text/plain", "", "Peer most likely gone.");
                            }
                        }
                        else if (peer->IsWaitRequest(ds))
                        {
                            // 如果socket发起的是/wait请求，无需关闭.
                            need_close_socket = false;
                        }
                        else
                        {
                            QHPeerConnection* target = pcm.FindTargetPeer(ds);
                            if (target)
                            {
                                peer->ForwardRequestToPeer(ds, target);
                            }
                            else if (ds->PathEquals("/sign_out"))
                            {
                                ds->Send("200 OK", true, "text/plain", "", "");
                            }
                            else
                            {
                                qDebug()<<"Couldn't find target for request: "<<ds->request_path().c_str();
                                ds->Send("500 Error", true, "text/plain", "", "Peer most likely gone.");
                            }
                        }
                    }
                    else
                    {
                        //  if (quit)
                        //  {
                        //      qDebug()<<("Quitting...\n");
                        //      FD_CLR(listener.socket(), &socket_set);
                        //      listener.Close();
                        //      pcm.Clear();
                        //  }
                    }
                }
            }
            else
            {
                need_close_socket = false;
            }

            if (need_close_socket)
            {
                pcm.Close(ds); // 此处不会关闭sokcet，仅关闭peer connection.
                FD_CLR(ds->socket(), &socket_set);
                delete (*i); // 最终会调用基类的析构来关闭socket.
                i = sockets.erase(i);
                if (i == sockets.end())
                {
                    break;
                }
            }
        }
        // 30秒超时，用于检测peer异常退出.
        pcm.CheckForTimeout();
        // 添加新的socket.
        if (FD_ISSET(listener.socket(), &socket_set))
        {
            QHDataSocket* ds = listener.Accept();
            if (sockets.size() >= kMaxConnections)
            {
                delete ds;
                qDebug()<<"Connection limit reached";
            }
            else
            {
                qDebug()<<"New connecting...";
                sockets.push_back(ds);
            }
        }
    }

    for (SocketArray::iterator i = sockets.begin(); i != sockets.end(); ++i)
    {
        delete (*i);
    }
    sockets.clear();

    a.exec();
}
