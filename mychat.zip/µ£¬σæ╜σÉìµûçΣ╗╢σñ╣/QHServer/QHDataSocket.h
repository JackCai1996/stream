#ifndef QHDATASOCKET_H
#define QHDATASOCKET_H

#include "QHSocketBase.h"

#include <string>
// Represents an HTTP server socket.
class QHDataSocket : public QHSocketBase
{
public:
    enum RequestMethod {
        INVALID,
        GET,
        POST,
        OPTIONS,
    };
public:
    QHDataSocket(NativeSocket socket);
    ~QHDataSocket();

public:
    RequestMethod method() const;
    // for example:/wait?peer_id=3
    const std::string& request_path() const;
    // for example:peer_id=3
    std::string request_arguments() const;
    // data为sdp或者candidate信息，否则为空.
    const std::string& data() const;
    //for example:text/plain
    const std::string& content_type() const;
    size_t content_length() const;
    bool request_received() const;
    // Checks if the request path matches a given path(for example:/wait).
    bool PathEquals(const char* path) const;
    // Called when we have received some data from peers.
    // Returns false if an error occurred.
    bool ReceiveData(bool* need_close_socket);
    // Send an HTTP response.
    // The |status| should start with a valid HTTP response code, followed by a string.  E.g. "200 OK".
    // If |connection_close| is set to true, an extra "Connection: close" HTTP header will be included.
    // |content_type| is the mime content type, not including the "Content-Type: " string.
    // |extra_headers| should be either empty or a list of headers where each header terminates with "\r\n".
    // |data| is the body of the message.  It's length will be specified via a "Content-Length" header.
    bool Send(const std::string& status,
              bool connection_close,
              const std::string& content_type,
              const std::string& extra_headers,
              const std::string& data) const;

protected:
    bool headers_received() const;
    bool data_received() const;
    // A fairly relaxed HTTP header parser.  Parses the method, path and
    // content length (POST only) of a request.
    // Returns true if a valid request was received and no errors occurred.
    bool ParseHeaders();
    // Figures out whether the request is a GET or POST and what path is
    // being requested.
    bool ParseMethodAndPath(const char* begin, size_t len);
    // Determines the length of the body and it's mime type.
    bool ParseContentLengthAndType(const char* headers, size_t length);

private:
    RequestMethod method_;
    size_t content_length_;
    std::string content_type_;
    std::string request_path_;
    std::string request_headers_;
    std::string data_;

    static const char kCrossOriginAllowHeaders[];
};

#endif // QHDATASOCKET_H
