#include "QHSocketBase.h"

#if defined(WIN32)
class WinsockInitializer
{
    static WinsockInitializer singleton;

    WinsockInitializer()
    {
        WSADATA data;
        WSAStartup(MAKEWORD(1, 0), &data);
    }

public:
    ~WinsockInitializer() { WSACleanup(); }
};
WinsockInitializer WinsockInitializer::singleton;
#endif

QHSocketBase::QHSocketBase()
    : socket_(INVALID_SOCKET)
{

}

QHSocketBase::QHSocketBase(NativeSocket socket)
    : socket_(socket)
{

}

QHSocketBase::~QHSocketBase()
{
    Close();
}

NativeSocket QHSocketBase::socket() const
{
    return socket_;
}

bool QHSocketBase::valid() const
{
    return socket_ != INVALID_SOCKET;
}

bool QHSocketBase::Create()
{
    if(!valid())
    {
        socket_ = ::socket(AF_INET, SOCK_STREAM, 0);
    }

    return valid();
}

void QHSocketBase::Close()
{
    if (socket_ != INVALID_SOCKET)
    {
        closesocket(socket_);
        socket_ = INVALID_SOCKET;
    }
}
