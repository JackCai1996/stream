#include "QHDataSocket.h"

#include <QDebug>

static const char kHeaderTerminator[] = "\r\n\r\n";
static const int kHeaderTerminatorLength = sizeof(kHeaderTerminator) - 1;

// static
const char QHDataSocket::kCrossOriginAllowHeaders[] =
        "Access-Control-Allow-Origin: *\r\n"
        "Access-Control-Allow-Credentials: true\r\n"
        "Access-Control-Allow-Methods: POST, GET, OPTIONS\r\n"
        "Access-Control-Allow-Headers: Content-Type, "
        "Content-Length, Connection, Cache-Control\r\n"
        "Access-Control-Expose-Headers: Content-Length\r\n";

QHDataSocket::QHDataSocket(NativeSocket socket)
    : QHSocketBase(socket)
    , method_(INVALID)
    , content_length_(0)
{

}

QHDataSocket::~QHDataSocket()
{

}

QHDataSocket::RequestMethod QHDataSocket::method() const
{
    return method_;
}

const std::string& QHDataSocket::request_path() const
{
    return request_path_;
}

std::string QHDataSocket::request_arguments() const
{
    size_t args = request_path_.find('?');
    if (args != std::string::npos)
    {
        return request_path_.substr(args + 1);
    }

    return "";
}

const std::string& QHDataSocket::data() const
{
    return data_;
}

const std::string& QHDataSocket::content_type() const
{
    return content_type_;
}

size_t QHDataSocket::content_length() const
{
    return content_length_;
}

bool QHDataSocket::request_received() const
{
    return headers_received() &&  data_received();
}

bool QHDataSocket::PathEquals(const char* path) const
{
    if(path)
    {
        size_t args = request_path_.find('?');
        if (args != std::string::npos)
        {
            return request_path_.substr(0, args).compare(path) == 0;
        }
        return request_path_.compare(path) == 0;
    }
    return false;
}

bool QHDataSocket::ReceiveData(bool *need_close_socket)
{
    if(!valid())
    {
        return false;
    }

    char buffer[0xfff] = {0};
    int bytes = recv(socket_, buffer, sizeof(buffer), 0);
    if (bytes == SOCKET_ERROR || bytes == 0)
    {
        *need_close_socket = true;
        return false;
    }

    *need_close_socket = false;

    bool ret = true;
    if (headers_received())
    {
        if (method_ != POST)
        {
            // unexpectedly received data.
            ret = false;
        }
        else
        {
            data_.append(buffer, bytes);
        }
    }
    else
    {
        request_headers_.append(buffer, bytes);
        size_t found = request_headers_.find(kHeaderTerminator);
        if (found != std::string::npos)
        {
            data_ = request_headers_.substr(found + kHeaderTerminatorLength);
            request_headers_.resize(found + kHeaderTerminatorLength);
            ret = ParseHeaders();
        }
    }
    return ret;
}

bool QHDataSocket::Send(const std::string& status,
                        bool connection_close,
                        const std::string& content_type,
                        const std::string& extra_headers,
                        const std::string& data) const
{
    if(!valid() || status.empty())
    {
        return false;
    }

    std::string buffer("HTTP/1.1 " + status + "\r\n");

    buffer += "Server: PeerConnectionTestServer/0.1\r\n"
              "Cache-Control: no-cache\r\n";

    if (connection_close)
    {
        buffer += "Connection: close\r\n";
    }

    if (!content_type.empty())
    {
        buffer += "Content-Type: " + content_type + "\r\n";
    }

    buffer += "Content-Length: " + QString::number(data.size()).toStdString() + "\r\n";

    if (!extra_headers.empty())
    {
        buffer += extra_headers;
        // Extra headers are assumed to have a separator per header.
    }

    buffer += kCrossOriginAllowHeaders;
    buffer += "\r\n";
    buffer += data;

    return send(socket_, buffer.data(), static_cast<int>(buffer.length()), 0) != SOCKET_ERROR;
}

bool QHDataSocket::headers_received() const
{
    return method_ != INVALID;
}

bool QHDataSocket::data_received() const
{
    return method_ != POST || data_.length() >= content_length_;
}

bool QHDataSocket::ParseHeaders()
{
    if(request_headers_.empty() || method_ != INVALID)
    {
        return false;
    }
    size_t i = request_headers_.find("\r\n");
    if (i == std::string::npos)
    {
        return false;
    }

    if (!ParseMethodAndPath(request_headers_.data(), i))
    {
        return false;
    }

    if(request_path_.empty() || method_ == INVALID)
    {
        return false;
    }

    if (method_ == POST)
    {
        const char* headers = request_headers_.data() + i + 2;
        size_t len = request_headers_.length() - i - 2;
        if (!ParseContentLengthAndType(headers, len))
        {
            return false;
        }
    }

    return true;
}

bool QHDataSocket::ParseMethodAndPath(const char* begin, size_t len)
{
    struct {
        const char* method_name;
        size_t method_name_len;
        RequestMethod id;
    } supported_methods[] = {
    {"GET", 3, GET},
    {"POST", 4, POST},
    {"OPTIONS", 7, OPTIONS},
};

    const char* path = nullptr;
    for (size_t i = 0; i < ARRAYSIZE(supported_methods); ++i)
    {
        if (len > supported_methods[i].method_name_len &&
                isspace(begin[supported_methods[i].method_name_len]) &&
                strncmp(begin, supported_methods[i].method_name,
                        supported_methods[i].method_name_len) == 0)
        {
            method_ = supported_methods[i].id;
            path = begin + supported_methods[i].method_name_len;
            break;
        }
    }

    const char* end = begin + len;
    if (!path || path >= end)
    {
        return false;
    }

    ++path;
    begin = path;
    while (!isspace(*path) && path < end)
    {
        ++path;
    }

    request_path_.assign(begin, path - begin);

    return true;
}

bool QHDataSocket::ParseContentLengthAndType(const char* headers, size_t length)
{
    if(content_length_!=0 || !content_type_.empty())
    {
        return false;
    }

    const char* end = headers + length;
    while (headers && headers < end)
    {
        if (!isspace(headers[0]))
        {
            static const char kContentLength[] = "Content-Length:";
            static const char kContentType[] = "Content-Type:";
            if ((headers + ARRAYSIZE(kContentLength)) < end &&
                    strncmp(headers, kContentLength, ARRAYSIZE(kContentLength) - 1) == 0)
            {
                headers += ARRAYSIZE(kContentLength) - 1;
                while (headers[0] == ' ')
                {
                    ++headers;
                }
                content_length_ = atoi(headers);
            }
            else if ((headers + ARRAYSIZE(kContentType)) < end &&
                     strncmp(headers, kContentType, ARRAYSIZE(kContentType) - 1) == 0)
            {
                headers += ARRAYSIZE(kContentType) - 1;
                while (headers[0] == ' ')
                {
                    ++headers;
                }

                const char* type_end = strstr(headers, "\r\n");
                if (type_end == nullptr)
                {
                    type_end = end;
                }
                content_type_.assign(headers, type_end);
            }
        }
        else
        {
            ++headers;
        }
        headers = strstr(headers, "\r\n");
        if (headers)
        {
            headers += 2;
        }
    }

    return !content_type_.empty() && content_length_ != 0;
}
