#include "QHPeerConnection.h"

#include <QDebug>

// Set to the peer id of the originator when messages are being
// exchanged between peers, but set to the id of the receiving peer
// itself when notifications are sent from the server about the state
// of other peers.
static const char kPeerIdHeader[] = "Pragma: ";

const size_t kMaxNameLength = 512;

int QHPeerConnection::s_peer_id_ = 0;

QHPeerConnection::QHPeerConnection(QHDataSocket* socket)
    : wait_socket_(nullptr),
      id_(++s_peer_id_),
      connected_(true),
      timestamp_(time(nullptr))
{
    if(socket)
    {
        // 从登陆中获取name.
        if((socket->method() == QHDataSocket::GET) && socket->PathEquals("/sign_in"))
        {
            name_ = socket->request_arguments();
            if (name_.empty())
            {
                name_ = "peer_" + QString::number(id_).toStdString();
            }
            else if (name_.length() > kMaxNameLength)
            {
                name_.resize(kMaxNameLength);
            }

            std::replace(name_.begin(), name_.end(), ',', '_');
        }
    }
}

QHPeerConnection::~QHPeerConnection()
{

}

bool QHPeerConnection::IsConnected() const
{
    return connected_;
}

int QHPeerConnection::Id() const
{
    return id_;
}

const std::string& QHPeerConnection::Name() const
{
    return name_;
}

void QHPeerConnection::Disconnect()
{
    connected_ = false;
}

bool QHPeerConnection::IsWaitRequest(QHDataSocket* ds) const
{
    return ds && ds->PathEquals(kRequestPaths[kWait]);
}

// wait_socket不存在超时的问题，其他socket 30秒超时.
bool QHPeerConnection::IsTimedOut()
{
    return wait_socket_ == nullptr && (time(nullptr) - timestamp_) > 30;
}

std::string QHPeerConnection::GetPeerIdHeader() const
{
    std::string ret(kPeerIdHeader + QString::number(id_).toStdString() + "\r\n");
    return ret;
}

bool QHPeerConnection::NotifyOtherPeers(const QHPeerConnection& other)
{
    if(&other != this)
    {
        QueueResponse("200 OK", "text/plain", GetPeerIdHeader(), other.GetEntry());
        return true;
    }

    return false;
}

std::string QHPeerConnection::GetEntry() const
{
    char entry[kMaxNameLength + 15];
    snprintf(entry, sizeof(entry), "%s,%d,%d\n",
             name_.substr(0, kMaxNameLength).c_str(), id_, connected_);
    return entry;
}

void QHPeerConnection::ForwardRequestToPeer(QHDataSocket* ds, QHPeerConnection* peer)
{
    if(!ds || !peer)
    {
        return;
    }

    std::string extra_headers(GetPeerIdHeader());

    if (peer == this)
    {
        ds->Send("200 OK", true, ds->content_type(), extra_headers, ds->data());
    }
    else
    {
        qDebug()<<QString("Peer %1 sending to %2\n").arg(name_.c_str()).arg(peer->Name().c_str());
        peer->QueueResponse("200 OK", ds->content_type(), extra_headers, ds->data());
        ds->Send("200 OK", true, "text/plain", "", "");
    }
}

void QHPeerConnection::Close(QHDataSocket* ds)
{
    if (ds == wait_socket_)
    {
        wait_socket_ = nullptr;
        timestamp_ = time(nullptr);
    }
}

void QHPeerConnection::QueueResponse(const std::string& status,
                                     const std::string& content_type,
                                     const std::string& extra_headers,
                                     const std::string& data)
{
    if (wait_socket_)
    {
        if(queue_.empty() && wait_socket_->method() == QHDataSocket::GET)
        {
            bool ok = wait_socket_->Send(status, true, content_type, extra_headers, data);
            if (!ok)
            {
                qDebug()<<"Failed to deliver data to wait socket";
            }
            wait_socket_ = nullptr;
            timestamp_ = time(nullptr);
        }
    }
    else
    {
        Response qr;
        qr.status = status;
        qr.content_type = content_type;
        qr.extra_headers = extra_headers;
        qr.data = data;
        queue_.push(qr);
    }
}

void QHPeerConnection::SetWaitSocket(QHDataSocket* ds)
{
    if(ds && ds->method() == QHDataSocket::GET)
    {
        if (!queue_.empty())
        {
            if(wait_socket_ == nullptr)
            {
                const Response& response = queue_.front();
                ds->Send(response.status, true, response.content_type,
                         response.extra_headers, response.data);
                queue_.pop();
            }
        }
        else
        {
            wait_socket_ = ds;
        }
    }
}
