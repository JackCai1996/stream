#include "QHListenSocket.h"

#include <QDebug>

QHListenSocket::QHListenSocket()
{
    if (!Create())
    {
        qDebug()<<"Failed to create listen socket";
    }
}

QHListenSocket::~QHListenSocket()
{

}

bool QHListenSocket::Listen(unsigned short port)
{
    if (!valid())
    {
        return false;
    }

    int enabled = 1;
    setsockopt(socket_, SOL_SOCKET, SO_REUSEADDR,
               reinterpret_cast<const char*>(&enabled), sizeof(enabled));
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(port);
    if (bind(socket_, reinterpret_cast<const sockaddr*>(&addr), sizeof(addr)) == SOCKET_ERROR)
    {
        qDebug()<<"Sokcet bind failed";
        return false;
    }
    return listen(socket_, 5) != SOCKET_ERROR;
}

QHDataSocket* QHListenSocket::Accept() const
{
    if(!valid())
    {
        return nullptr;
    }

    struct sockaddr_in addr = {0};
    socklen_t size = sizeof(addr);
    NativeSocket clientSocket = accept(socket_, reinterpret_cast<sockaddr*>(&addr), &size);
    if (clientSocket == INVALID_SOCKET)
    {
        return nullptr;
    }
    return new QHDataSocket(clientSocket);
}
