#include "QHPeerConnectionManager.h"

#include <QDebug>

QHPeerConnectionManager::QHPeerConnectionManager()
{

}

QHPeerConnectionManager::~QHPeerConnectionManager()
{

}

bool QHPeerConnectionManager::IsNewConnection(const QHDataSocket* ds)
{
    if(ds)
    {
        return (ds->method() == QHDataSocket::POST && ds->content_length() > 0) ||
                (ds->method() == QHDataSocket::GET && ds->PathEquals("/sign_in"));
    }
    return false;
}

QHPeerConnection* QHPeerConnectionManager::FindPeer(QHDataSocket* ds) const
{
    if(ds)
    {
        if (ds->method() != QHDataSocket::GET && ds->method() != QHDataSocket::POST)
        {
            return nullptr;
        }

        size_t i = 0;
        for (; i < ARRAYSIZE(kRequestPaths); ++i)
        {
            if (ds->PathEquals(kRequestPaths[i]))
            {
                break;
            }
        }

        if (i == ARRAYSIZE(kRequestPaths))
        {
            return nullptr;
        }
        // 只有 "/wait","/sign_out","/message"这三种类型消息的参数是peer_id=....
        std::string args(ds->request_arguments());
        static const char kPeerId[] = "peer_id=";
        size_t found = args.find(kPeerId);
        // 如果找不到，返回.
        if (found == std::string::npos)
        {
            return nullptr;
        }

        int id = atoi(&args[found + ARRAYSIZE(kPeerId) - 1]);
        Peers::const_iterator iter = peers_.begin();
        for (; iter != peers_.end(); ++iter)
        {
            if (id == (*iter)->Id())
            {
                if (i == kWait)
                {
                    (*iter)->SetWaitSocket(ds);
                }
                if (i == kSignOut)
                {
                    (*iter)->Disconnect();
                }

                return *iter;
            }
        }
    }

    return nullptr;
}

QHPeerConnection* QHPeerConnectionManager::FindTargetPeer(const QHDataSocket* ds) const
{
    if(ds)
    {
        // Regardless of GET or POST, we look for the peer_id parameter
        // only in the request_path.
        const std::string& path = ds->request_path();
        size_t args = path.find('?');
        if (args == std::string::npos)
        {
            return nullptr;
        }
        size_t found;
        const char kTargetPeerIdParam[] = "to=";
        do {
            found = path.find(kTargetPeerIdParam, args);
            if (found == std::string::npos)
            {
                return nullptr;
            }
            if (found == (args + 1) || path[found - 1] == '&')
            {
                found += ARRAYSIZE(kTargetPeerIdParam) - 1;
                break;
            }
            args = found + ARRAYSIZE(kTargetPeerIdParam) - 1;
        } while (true);
        int id = atoi(&path[found]);
        Peers::const_iterator i = peers_.begin();
        for (; i != peers_.end(); ++i)
        {
            if ((*i)->Id() == id)
            {
                return *i;
            }
        }
    }

    return nullptr;
}

bool QHPeerConnectionManager::AddPeer(QHDataSocket* ds)
{
    if(IsNewConnection(ds))
    {
        QHPeerConnection* new_peer = new QHPeerConnection(ds);
        Peers failures;
        BroadcastChangedState(*new_peer);
        peers_.push_back(new_peer);

        qDebug()<<QString("Add peer (total=%1): Name is %2,ID is %3").arg(peers_.size()).arg(new_peer->Name().c_str()).arg(new_peer->Id());

        // Let the newly connected peer know about other peers.
        std::string response = BuildResponseForNewPeer(*new_peer);
        ds->Send("200 Added", true, "text/plain", new_peer->GetPeerIdHeader(), response);
        return true;
    }
    return false;
}

void QHPeerConnectionManager::Clear()
{
    Peers::const_iterator i = peers_.begin();
    for (; i != peers_.end(); ++i)
    {
        (*i)->QueueResponse("200 OK", "text/plain", "", "Server shutting down");
    }

    for (Peers::iterator i = peers_.begin(); i != peers_.end(); ++i)
    {
        delete (*i);
    }
    peers_.clear();
}

void QHPeerConnectionManager::Close(QHDataSocket* ds)
{
    for (Peers::iterator i = peers_.begin(); i != peers_.end(); ++i)
    {
        QHPeerConnection* peer = (*i);
        qDebug()<<QString("Close peer: Name is %1,ID is %2").arg(peer->Name().c_str()).arg(peer->Id());
        peer->Close(ds);
        if (!peer->IsConnected())
        {
            i = peers_.erase(i);
            Peers failures;
            BroadcastChangedState(*peer);
            delete peer;
            if (i == peers_.end())
            {
                break;
            }
        }
    }
    qDebug()<<QString("Total connected: %1").arg(peers_.size());
}

void QHPeerConnectionManager::CheckForTimeout()
{
    for (Peers::iterator i = peers_.begin(); i != peers_.end(); ++i)
    {
        QHPeerConnection* peer = (*i);
        if (peer->IsTimedOut())
        {
            qDebug()<<QString("Timeout: Name is %1,ID is %2").arg(peer->Name().c_str()).arg(peer->Id());
            peer->Disconnect();
            i = peers_.erase(i);
            Peers failures;
            BroadcastChangedState(*peer);
            delete peer;
            if (i == peers_.end())
            {
                break;
            }
        }
    }
}

void QHPeerConnectionManager::BroadcastChangedState(const QHPeerConnection& peer)
{
    if (!peer.IsConnected())
    {
        qDebug()<<QString("Peer disconnected: Name is %1,ID is %2").arg(peer.Name().c_str()).arg(peer.Id());
    }

    Peers::iterator i = peers_.begin();
    for (; i != peers_.end(); ++i)
    {
        if (&peer != (*i))
        {
            // if中做了不是自身的判断，因此NotifyOtherPeer总是返回true.
            (*i)->NotifyOtherPeers(peer);
        }
    }
}

std::string QHPeerConnectionManager::BuildResponseForNewPeer(const QHPeerConnection& peer)
{
    // The peer itself will always be the first entry.
    std::string response(peer.GetEntry());
    for (Peers::iterator i = peers_.begin(); i != peers_.end(); ++i)
    {
        if (peer.Id() != (*i)->Id())
        {
            assert((*i)->IsConnected());
            response += (*i)->GetEntry();
        }
    }

    return response;
}
