#include "QHCapturerTrackSource.h"

#include <QDebug>

QHCapturerTrackSource::QHCapturerTrackSource(QHVideoCapturer *capturer)
    : VideoTrackSource(/*remote=*/false)
    , capturer_(capturer)
{
       capturer_->StartCapture();
}

rtc::VideoSourceInterface<webrtc::VideoFrame>* QHCapturerTrackSource::source()
{
    return capturer_;
}

QHCapturerTrackSource::~QHCapturerTrackSource()
{
    if(capturer_)
    {
        capturer_->StopCapture();
    }
}
