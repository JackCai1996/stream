#include "QHVideoRender.h"

#include <QDebug>

QHVideoRender::QHVideoRender(void *userData)
    : user_data_(userData)
{

}

QHVideoRender::~QHVideoRender()
{

}

void QHVideoRender::OnFrame(const VideoFrame& videoFrame)
{
    MutexLock lock(&mutex_);

    int height = videoFrame.height();
    int width = videoFrame.width();

    if(height>0 && width>0)
    {
        SignalVideoFrame(user_data_,videoFrame);
    }
}

