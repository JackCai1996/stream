#include "QHPeerConnection.h"

#include "api/audio_codecs/builtin_audio_decoder_factory.h"
#include "api/audio_codecs/builtin_audio_encoder_factory.h"
#include "api/audio_options.h"
#include "api/create_peerconnection_factory.h"
#include "api/rtp_sender_interface.h"
#include "api/video_codecs/builtin_video_decoder_factory.h"
#include "api/video_codecs/builtin_video_encoder_factory.h"
#include "rtc_base/strings/json.h"

#include "QHCapturerTrackSource.h"
#include "QHVideoRender.h"
#include "QHVideoCapturer.h"
#include "QHAudioDevice.h"

const char kAudioLabel[] = "audio_label";
const char kVideoLabel[] = "video_label";
const char kStreamId[] = "stream_id";
const uint16_t kDefaultServerPort = 8888;
const std::string kDefalutServerUri = "stun:stun.l.google.com:19302";

// Names used for a IceCandidate JSON object.
const char kCandidateSdpMidName[] = "sdpMid";
const char kCandidateSdpMlineIndexName[] = "sdpMLineIndex";
const char kCandidateSdpName[] = "candidate";

// Names used for a SessionDescription JSON object.
const char kSessionDescriptionTypeName[] = "type";
const char kSessionDescriptionSdpName[] = "sdp";

// This is our magical hangup signal.
const char kByeMessage[] = "BYE";
// Delay between server connection retries, in milliseconds
const int kReconnectDelay = 2000;

QHPeerConnection::QHPeerConnection(QHVideoRender *local_render,QHVideoRender *remote_render,QHVideoCapturer *video_capturer,QHAudioDevice *audio_device)
    : local_render_(local_render)
    , remote_render_(remote_render)
    , video_capturer_(video_capturer)
    , audio_device_(audio_device)
{

}

QHPeerConnection::~QHPeerConnection()
{

}

void QHPeerConnection::ConnectToPeer(int peer_id)
{
    if(peer_id == -1)
    {
        qDebug()<<"Peer id error"<<"++++++++++++++++++++++";
        return;
    }

    if(peer_connection_)
    {
        qDebug()<<"We only support connecting to one peer at a time"<<"++++++++++++++++++++++";
        return;
    }
    // 在ConnectToPeer中，此处是主动发起连接.
    if(InitializePeerConnection())
    {
        peer_id_ = peer_id;
        peer_connection_->CreateOffer(this, webrtc::PeerConnectionInterface::RTCOfferAnswerOptions());
    }
}

// 主动断开和peer的连接.
void QHPeerConnection::DisconnectFromPeer()
{
    if (peer_connection_)
    {
        DoSend(peer_id_, kByeMessage);
        DeletePeerConnection();
    }
}

void QHPeerConnection::Login(const std::string& server, int port)
{
    if(my_id_ != -1)
    {
        return;
    }

    ConnectToServer(server,port,GetPeerName());
}

bool QHPeerConnection::Logout()
{
    if (state_ == NOT_CONNECTED || state_ == SIGNING_OUT)
    {
        return true;
    }

    if (hanging_socket_->GetState() != rtc::Socket::CS_CLOSED)
    {
        hanging_socket_->Close();
    }

    if (control_socket_->GetState() == rtc::Socket::CS_CLOSED)
    {
        state_ = SIGNING_OUT;

        if (my_id_ != -1)
        {
            char buffer[1024];
            snprintf(buffer, sizeof(buffer), "GET /sign_out?peer_id=%i HTTP/1.0\r\n\r\n", my_id_);
            onconnect_data_ = buffer;
            return ConnectControlSocket();
        }
        else
        {
            // Can occur if the app is closed before we finish connecting.
            return true;
        }
    }
    else
    {
        state_ = SIGNING_OUT_WAITING;
    }

    return true;
}

bool QHPeerConnection::IsLogined()
{
    return my_id_ != -1;
}

bool QHPeerConnection::InitializePeerConnection()
{
    peer_connection_factory_ = CreatePeerConnectionFactory(
                rtc::Thread::Current()  /* network_thread */,
                rtc::Thread::Current()  /* worker_thread */,
                rtc::Thread::Current()  /* signaling_thread */,
                audio_device_->Device(),
                CreateBuiltinAudioEncoderFactory(),
                CreateBuiltinAudioDecoderFactory(),
                CreateBuiltinVideoEncoderFactory(),
                CreateBuiltinVideoDecoderFactory(),
                nullptr /* audio_mixer */,
                nullptr /* audio_processing */);

    if(!peer_connection_factory_)
    {
        qDebug()<<"Failed to initialize PeerConnectionFactory"<<"++++++++++++++++++++++";
        DeletePeerConnection();
        return false;
    }

    if(!CreatePeerConnection(/*dtls=*/true))
    {
        qDebug()<<"CreatePeerConnection failed"<<"++++++++++++++++++++++";
        DeletePeerConnection();
        return false;
    }

    AddTracks();

    pending_messages_.clear();

    return peer_connection_ != nullptr;
}

bool QHPeerConnection::CreatePeerConnection(bool dtls)
{
    PeerConnectionInterface::RTCConfiguration config;
    config.sdp_semantics = SdpSemantics::kUnifiedPlan;
    config.enable_dtls_srtp = dtls;
    PeerConnectionInterface::IceServer server;
    server.uri = kDefalutServerUri;
    config.servers.push_back(server);

    peer_connection_ = peer_connection_factory_->CreatePeerConnection(
                config, nullptr, nullptr, this);

    return peer_connection_ != nullptr;
}

void QHPeerConnection::DeletePeerConnection()
{
    peer_connection_ = nullptr;
    peer_connection_factory_ = nullptr;
    peer_id_ = -1;
}

void QHPeerConnection::AddTracks()
{
    if (!peer_connection_->GetSenders().empty())
    {
        qDebug()<<"Already added tracks"<<"++++++++++++++++++++++";
        return;
    }

    rtc::scoped_refptr<AudioSourceInterface> audio_source =
            peer_connection_factory_->CreateAudioSource(cricket::AudioOptions());
    if(audio_source)
    {
        rtc::scoped_refptr<AudioTrackInterface> audio_track(
                    peer_connection_factory_->CreateAudioTrack(kAudioLabel, audio_source));

        auto result_or_error = peer_connection_->AddTrack(audio_track, {kStreamId});
        if (!result_or_error.ok())
        {
            qDebug() << "Failed to add audio track to PeerConnection: "<< result_or_error.error().message()<<"++++++++++++++++++++++";
        }
    }

    rtc::scoped_refptr<QHCapturerTrackSource> video_device =
            new rtc::RefCountedObject<QHCapturerTrackSource>(video_capturer_);
    if (video_device)
    {
        rtc::scoped_refptr<webrtc::VideoTrackInterface> video_track(
                    peer_connection_factory_->CreateVideoTrack(kVideoLabel, video_device));
        video_track->AddOrUpdateSink(local_render_, rtc::VideoSinkWants());

        auto result_or_error = peer_connection_->AddTrack(video_track, {kStreamId});
        if (!result_or_error.ok())
        {
            qDebug() << "Failed to add video track to PeerConnection: "<< result_or_error.error().message()<<"++++++++++++++++++++++";
        }
    }
    else
    {
        qDebug() << "OpenVideoCaptureDevice failed"<<"++++++++++++++++++++++";
    }
}

rtc::AsyncSocket* QHPeerConnection::CreateSocket(int family)
{
#ifdef WIN32
    rtc::Win32Socket* sock = new rtc::Win32Socket();
    sock->CreateT(family, SOCK_STREAM);
    return sock;
#endif
}

bool QHPeerConnection::ConnectControlSocket()
{
    if(control_socket_->GetState() == rtc::Socket::CS_CLOSED)
    {
        int err = control_socket_->Connect(server_address_);
        if (err == SOCKET_ERROR)
        {
            CloseSocket();
        }
        else
        {
            return true;
        }
    }
    return  false;
}

void QHPeerConnection::CloseSocket()
{
    control_socket_->Close();
    hanging_socket_->Close();

    if (resolver_ != nullptr)
    {
        resolver_->Destroy(false);
        resolver_ = nullptr;
    }

    onconnect_data_.clear();
    state_ = NOT_CONNECTED;
    my_id_ = -1;
}

void QHPeerConnection::ConnectToServer(const std::string& server, int port, const std::string& client_name)
{
    if(!server.empty() && !client_name.empty())
    {
        if (state_ != NOT_CONNECTED)
        {
            qDebug()<<"The client must not be connected before you can call Connect()"<<"++++++++++++++++++++++";
            return;
        }

        if (port <= 0 || port >65535)
        {
            port = kDefaultServerPort;
        }

        server_address_.SetIP(server);
        server_address_.SetPort(port);
        client_name_ = client_name;

        if (server_address_.IsUnresolvedIP())
        {
            state_ = RESOLVING;
            resolver_ = new rtc::AsyncResolver();
            resolver_->SignalDone.connect(this, &QHPeerConnection::OnResolveResult);
            resolver_->Start(server_address_);
        }
        else
        {
            DoConnect();
        }
    }
}

void QHPeerConnection::DoConnect()
{
    control_socket_.reset(CreateSocket(server_address_.ipaddr().family()));
    hanging_socket_.reset(CreateSocket(server_address_.ipaddr().family()));

    control_socket_->SignalCloseEvent.connect(this,&QHPeerConnection::OnClose);
    hanging_socket_->SignalCloseEvent.connect(this,&QHPeerConnection::OnClose);
    control_socket_->SignalConnectEvent.connect(this,&QHPeerConnection::OnControlConnect);
    hanging_socket_->SignalConnectEvent.connect(this,&QHPeerConnection::OnHangingConnect);
    control_socket_->SignalReadEvent.connect(this,&QHPeerConnection::OnControlRead);
    hanging_socket_->SignalReadEvent.connect(this,&QHPeerConnection::OnHangingRead);

    char buffer[1024];
    snprintf(buffer, sizeof(buffer), "GET /sign_in?%s HTTP/1.0\r\n\r\n", client_name_.c_str());
    onconnect_data_ = buffer;

    bool ret = ConnectControlSocket();
    if (ret)
    {
        state_ = SIGNING_IN;
    }
    else
    {
        qDebug()<<"ConnectControlSocket failed"<<"++++++++++++++++++++++";
    }
}

void QHPeerConnection::SendMessageToPeer(const std::string& message)
{
    if(!message.empty())
    {
        std::string* msg = new std::string(message);
        if (msg)
        {
            // For convenience, we always run the message through the queue.
            // This way we can be sure that messages are sent to the server
            // in the same order they were signaled without much hassle.
            pending_messages_.push_back(msg);
        }
    }

    if (!pending_messages_.empty() && !IsSendingMessage())
    {
        std::string* msg = pending_messages_.front();
        pending_messages_.pop_front();
        if (!DoSend(peer_id_, *msg) && peer_id_ != -1)
        {
            qDebug()<<"SendMessageToPeer failed"<<"++++++++++++++++++++++";
            if(my_id_ != -1)
            {
                Logout();
            }
        }
        delete msg;
    }

    if (!peer_connection_)
    {
        peer_id_ = -1;
    }
}

bool QHPeerConnection::DoSend(int peer_id, const std::string& message)
{
    if (state_ != CONNECTED)
        return false;

    if (my_id_ == -1 || peer_id == -1)
        return false;

    char headers[1024];
    snprintf(headers, sizeof(headers),
             "POST /message?peer_id=%i&to=%i HTTP/1.0\r\n"
             "Content-Length: %zu\r\n"
             "Content-Type: text/plain\r\n"
             "\r\n",
             my_id_, peer_id, message.length());
    onconnect_data_ = headers;
    onconnect_data_ += message;

    return ConnectControlSocket();
}

bool QHPeerConnection::IsSendingMessage()
{
    return state_ == CONNECTED && control_socket_->GetState() != rtc::Socket::CS_CLOSED;
}

//HTTP/1.1 200 OK
//Server: PeerConnectionTestServer/0.1
//Cache-Control: no-cache
//Connection: close
//Content-Type: text/plain
//Content-Length: 5120
//Pragma: 15
//Access-Control-Allow-Origin: *
//Access-Control-Allow-Credentials: true
//Access-Control-Allow-Methods: POST, GET, OPTIONS
//Access-Control-Allow-Headers: Content-Type, Content-Length, Connection, Cache-Control
//Access-Control-Expose-Headers: Content-Length

//{
//   "sdp" : "v=0\r\no=- 1584349685883932684 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\na=group:BUNDLE 0 1\r\na=extmap-allow-mixed\r\na=msid-semantic: WMS stream_id\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111 103 104 9 102 0 8 106 105 13 110 112 113 126\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:oPR1\r\na=ice-pwd:O0hPEYI8s5o3fFCPRGR89pd0\r\na=ice-options:trickle\r\na=fingerprint:sha-256 F7:24:2C:5B:5D:11:2D:45:7D:51:4C:92:A6:50:7E:18:C9:C2:11:E8:20:7C:90:D8:DE:3B:48:64:91:9C:B3:EC\r\na=setup:actpass\r\na=mid:0\r\na=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=extmap:5 urn:ietf:params:rtp-hdrext:sdes:rtp-stream-id\r\na=extmap:6 urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id\r\na=sendrecv\r\na=msid:stream_id audio_label\r\na=rtcp-mux\r\na=rtpmap:111 opus/48000/2\r\na=rtcp-fb:111 transport-cc\r\na=fmtp:111 minptime=10;useinbandfec=1\r\na=rtpmap:103 ISAC/16000\r\na=rtpmap:104 ISAC/32000\r\na=rtpmap:9 G722/8000\r\na=rtpmap:102 ILBC/8000\r\na=rtpmap:0 PCMU/8000\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:106 CN/32000\r\na=rtpmap:105 CN/16000\r\na=rtpmap:13 CN/8000\r\na=rtpmap:110 telephone-event/48000\r\na=rtpmap:112 telephone-event/32000\r\na=rtpmap:113 telephone-event/16000\r\na=rtpmap:126 telephone-event/8000\r\na=ssrc:4261572771 cname:+XKcsJc3o1WY0VRo\r\na=ssrc:4261572771 msid:stream_id audio_label\r\na=ssrc:4261572771 mslabel:stream_id\r\na=ssrc:4261572771 label:audio_label\r\nm=video 9 UDP/TLS/RTP/SAVPF 96 97 98 99 100 101 127 120 125 119 124 107 108 109 123 118 122\r\nc=IN IP4 0.0.0.0\r\na=rtcp:9 IN IP4 0.0.0.0\r\na=ice-ufrag:oPR1\r\na=ice-pwd:O0hPEYI8s5o3fFCPRGR89pd0\r\na=ice-options:trickle\r\na=fingerprint:sha-256 F7:24:2C:5B:5D:11:2D:45:7D:51:4C:92:A6:50:7E:18:C9:C2:11:E8:20:7C:90:D8:DE:3B:48:64:91:9C:B3:EC\r\na=setup:actpass\r\na=mid:1\r\na=extmap:14 urn:ietf:params:rtp-hdrext:toffset\r\na=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\r\na=extmap:13 urn:3gpp:video-orientation\r\na=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\r\na=extmap:12 http://www.webrtc.org/experiments/rtp-hdrext/playout-delay\r\na=extmap:11 http://www.webrtc.org/experiments/rtp-hdrext/video-content-type\r\na=extmap:7 http://www.webrtc.org/experiments/rtp-hdrext/video-timing\r\na=extmap:8 http://www.webrtc.org/experiments/rtp-hdrext/color-space\r\na=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\r\na=extmap:5 urn:ietf:params:rtp-hdrext:sdes:rtp-stream-id\r\na=extmap:6 urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id\r\na=sendrecv\r\na=msid:stream_id video_label\r\na=rtcp-mux\r\na=rtcp-rsize\r\na=rtpmap:96 VP8/90000\r\na=rtcp-fb:96 goog-remb\r\na=rtcp-fb:96 transport-cc\r\na=rtcp-fb:96 ccm fir\r\na=rtcp-fb:96 nack\r\na=rtcp-fb:96 nack pli\r\na=rtpmap:97 rtx/90000\r\na=fmtp:97 apt=96\r\na=rtpmap:98 VP9/90000\r\na=rtcp-fb:98 goog-remb\r\na=rtcp-fb:98 transport-cc\r\na=rtcp-fb:98 ccm fir\r\na=rtcp-fb:98 nack\r\na=rtcp-fb:98 nack pli\r\na=fmtp:98 profile-id=0\r\na=rtpmap:99 rtx/90000\r\na=fmtp:99 apt=98\r\na=rtpmap:100 VP9/90000\r\na=rtcp-fb:100 goog-remb\r\na=rtcp-fb:100 transport-cc\r\na=rtcp-fb:100 ccm fir\r\na=rtcp-fb:100 nack\r\na=rtcp-fb:100 nack pli\r\na=fmtp:100 profile-id=2\r\na=rtpmap:101 rtx/90000\r\na=fmtp:101 apt=100\r\na=rtpmap:127 H264/90000\r\na=rtcp-fb:127 goog-remb\r\na=rtcp-fb:127 transport-cc\r\na=rtcp-fb:127 ccm fir\r\na=rtcp-fb:127 nack\r\na=rtcp-fb:127 nack pli\r\na=fmtp:127 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42001f\r\na=rtpmap:120 rtx/90000\r\na=fmtp:120 apt=127\r\na=rtpmap:125 H264/90000\r\na=rtcp-fb:125 goog-remb\r\na=rtcp-fb:125 transport-cc\r\na=rtcp-fb:125 ccm fir\r\na=rtcp-fb:125 nack\r\na=rtcp-fb:125 nack pli\r\na=fmtp:125 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=42001f\r\na=rtpmap:119 rtx/90000\r\na=fmtp:119 apt=125\r\na=rtpmap:124 H264/90000\r\na=rtcp-fb:124 goog-remb\r\na=rtcp-fb:124 transport-cc\r\na=rtcp-fb:124 ccm fir\r\na=rtcp-fb:124 nack\r\na=rtcp-fb:124 nack pli\r\na=fmtp:124 level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=42e01f\r\na=rtpmap:107 rtx/90000\r\na=fmtp:107 apt=124\r\na=rtpmap:108 H264/90000\r\na=rtcp-fb:108 goog-remb\r\na=rtcp-fb:108 transport-cc\r\na=rtcp-fb:108 ccm fir\r\na=rtcp-fb:108 nack\r\na=rtcp-fb:108 nack pli\r\na=fmtp:108 level-asymmetry-allowed=1;packetization-mode=0;profile-level-id=42e01f\r\na=rtpmap:109 rtx/90000\r\na=fmtp:109 apt=108\r\na=rtpmap:123 red/90000\r\na=rtpmap:118 rtx/90000\r\na=fmtp:118 apt=123\r\na=rtpmap:122 ulpfec/90000\r\na=ssrc-group:FID 644303369 2219136696\r\na=ssrc:644303369 cname:+XKcsJc3o1WY0VRo\r\na=ssrc:644303369 msid:stream_id video_label\r\na=ssrc:644303369 mslabel:stream_id\r\na=ssrc:644303369 label:video_label\r\na=ssrc:2219136696 cname:+XKcsJc3o1WY0VRo\r\na=ssrc:2219136696 msid:stream_id video_label\r\na=ssrc:2219136696 mslabel:stream_id\r\na=ssrc:2219136696 label:video_label\r\n",
//   "type" : "offer"
//}
//分割线————————————————————————————————————————————————————————————————————————————————
//HTTP/1.1 200 OK
//Server: PeerConnectionTestServer/0.1
//Cache-Control: no-cache
//Connection: close
//Content-Type: text/plain
//Content-Length: 170
//Pragma: 15
//Access-Control-Allow-Origin: *
//Access-Control-Allow-Credentials: true
//Access-Control-Allow-Methods: POST, GET, OPTIONS
//Access-Control-Allow-Headers: Content-Type, Content-Length, Connection, Cache-Control
//Access-Control-Expose-Headers: Content-Length

//{
//   "candidate" : "candidate:1526447285 1 udp 2122260223 192.168.43.57 59318 typ host generation 0 ufrag 8C+Z network-id 3",
//   "sdpMLineIndex" : 0,
//   "sdpMid" : "0"
//}
//分割线————————————————————————————————————————————————————————————————————————————————
//HTTP/1.1 200 OK
//Server: PeerConnectionTestServer/0.1
//Cache-Control: no-cache
//Connection: close
//Content-Type: text/plain
//Content-Length: 3
//Pragma: 20
//Access-Control-Allow-Origin: *
//Access-Control-Allow-Credentials: true
//Access-Control-Allow-Methods: POST, GET, OPTIONS
//Access-Control-Allow-Headers: Content-Type, Content-Length, Connection, Cache-Control
//Access-Control-Expose-Headers: Content-Length

//BYE
void QHPeerConnection::ReceiveMessageFromPeer(int peer_id, const std::string& message)
{
    if (message.length() == (sizeof(kByeMessage) - 1) && message.compare(kByeMessage) == 0)
    {
        // 如果收到的是当前连接的peer的bye message，则被动断开peer连接.
        if(peer_id == peer_id_)
        {
            DeletePeerConnection();
        }
    }
    else
    {
        if((peer_id_ == peer_id || peer_id_ == -1) && !message.empty())
        {
            // 如果第一次收到消息,获取peer_id_.
            if(!peer_connection_)
            {
                if(peer_id_ == -1)
                {
                    peer_id_ = peer_id;
                }
                // 被动连接到peer.
                if (!InitializePeerConnection())
                {
                    qDebug()<<"Failed to initialize our PeerConnection instance"<<"++++++++++++++++++++++";
                    Logout();
                    return;
                }
            }

            Json::Reader reader;
            Json::Value jmessage;
            if (!reader.parse(message, jmessage))
            {
                qDebug()<<"Received unknown message::"<<QString::fromStdString(message)<<"++++++++++++++++++++++";
                return;
            }
            std::string type_str;
            std::string json_object;

            rtc::GetStringFromJsonObject(jmessage, kSessionDescriptionTypeName, &type_str);
            if (!type_str.empty())
            {
                absl::optional<webrtc::SdpType> type_maybe = webrtc::SdpTypeFromString(type_str);
                if (!type_maybe)
                {
                    qDebug()<<"Unknown SDP type: "<<QString::fromStdString(type_str)<<"++++++++++++++++++++++";
                    return;
                }
                webrtc::SdpType type = *type_maybe;
                std::string sdp;
                if (!rtc::GetStringFromJsonObject(jmessage, kSessionDescriptionSdpName, &sdp))
                {
                    qDebug()<<"Can't parse received session description message.";
                    return;
                }
                webrtc::SdpParseError error;
                std::unique_ptr<webrtc::SessionDescriptionInterface> session_description =
                        webrtc::CreateSessionDescription(type, sdp, &error);
                if (!session_description)
                {
                    qDebug()<<"Can't parse received session description message.SdpParseError was: "
                           << QString::fromStdString(error.description)
                           << "++++++++++++++++++++++";
                    return;
                }
                qDebug()<<"Received session description :" << QString::fromStdString(message)<<"++++++++++++++++++++++";
                peer_connection_->SetRemoteDescription(
                            DummySetSessionDescriptionObserver::Create(),
                            session_description.release());
                if (type == webrtc::SdpType::kOffer)
                {
                    peer_connection_->CreateAnswer(this, webrtc::PeerConnectionInterface::RTCOfferAnswerOptions());
                }
            }
            else
            {
                std::string sdp_mid;
                int sdp_mlineindex = 0;
                std::string sdp;
                if (!rtc::GetStringFromJsonObject(jmessage, kCandidateSdpMidName, &sdp_mid) ||
                        !rtc::GetIntFromJsonObject(jmessage, kCandidateSdpMlineIndexName, &sdp_mlineindex) ||
                        !rtc::GetStringFromJsonObject(jmessage, kCandidateSdpName, &sdp))
                {
                    qDebug()<<"Can't parse received message."<<"++++++++++++++++++++++";
                    return;
                }
                webrtc::SdpParseError error;
                std::unique_ptr<webrtc::IceCandidateInterface> candidate(webrtc::CreateIceCandidate(sdp_mid, sdp_mlineindex, sdp, &error));
                if (!candidate.get())
                {
                    qDebug()<<"Can't parse received candidate message.SdpParseError was: "
                           <<QString::fromStdString(error.description)
                          <<"++++++++++++++++++++++";
                    return;
                }
                if (!peer_connection_->AddIceCandidate(candidate.get()))
                {
                    qDebug()<<"Failed to apply the received candidate"<<"++++++++++++++++++++++";
                    return;
                }
                qDebug()<<"Received candidate :"<<QString::fromStdString(message)<<"++++++++++++++++++++++";
            }
        }
    }
}

std::string QHPeerConnection::GetPeerName()
{
    char computer_name[256];
    std::string ret(GetEnvVarOrDefault("USERNAME", "user"));
    ret += '@';
    if (gethostname(computer_name, arraysize(computer_name)) == 0) {
        ret += computer_name;
    } else {
        ret += "host";
    }
    return ret;
}

std::string QHPeerConnection::GetEnvVarOrDefault(const char* env_var_name,const char* default_value)
{
    std::string value;
    const char* env_var = getenv(env_var_name);
    if (env_var)
    {
        value = env_var;
    }

    if (value.empty())
    {
        value = default_value;
    }

    return value;
}

bool QHPeerConnection::GetHeaderValue(const std::string& data,
                                      size_t eoh,
                                      const char* header_pattern,
                                      size_t* value)
{
    if(value)
    {
        size_t found = data.find(header_pattern);
        if (found != std::string::npos && found < eoh)
        {
            *value = atoi(&data[found + strlen(header_pattern)]);
            return true;
        }
    }
    return false;
}

bool QHPeerConnection::ReadIntoBuffer(rtc::AsyncSocket* socket,
                                      std::string* data,
                                      size_t* content_length)
{
    char buffer[0xffff];
    do
    {
        int bytes = socket->Recv(buffer, sizeof(buffer), nullptr);
        if (bytes <= 0)
            break;
        data->append(buffer, bytes);
    } while (true);

    bool ret = false;
    size_t i = data->find("\r\n\r\n");
    if (i != std::string::npos)
    {
        if (GetHeaderValue(*data, i, "\r\nContent-Length: ", content_length))
        {
            size_t total_response_size = (i + 4) + *content_length;
            if (data->length() >= total_response_size)
            {
                ret = true;
                std::string should_close;
                const char kConnection[] = "\r\nConnection: ";
                if (GetHeaderValue(*data, i, kConnection, &should_close) && should_close.compare("close") == 0)
                {
                    socket->Close();
                    // Since we closed the socket, there was no notification delivered
                    // to us.  Compensate by letting ourselves know.
                    OnClose(socket, 0);
                }
            }
            else
            {
                // We haven't received everything.  Just continue to accept data.
            }
        }
        else
        {
            qDebug()<<"No content length field specified by the server."<<"++++++++++++++++++++++";
        }
    }
    return ret;
}

bool QHPeerConnection::GetHeaderValue(const std::string& data,
                                      size_t eoh,
                                      const char* header_pattern,
                                      std::string* value)
{
    if(value)
    {
        size_t found = data.find(header_pattern);
        if (found != std::string::npos && found < eoh)
        {
            size_t begin = found + strlen(header_pattern);
            size_t end = data.find("\r\n", begin);
            if (end == std::string::npos)
            {
                end = eoh;
            }
            value->assign(data.substr(begin, end - begin));
            return true;
        }
    }
    return false;
}

bool QHPeerConnection::ParseEntry(const std::string& entry,
                                  std::string* name,
                                  int* id,
                                  bool* connected)
{
    if(name && id && connected && !entry.empty())
    {
        *connected = false;
        size_t separator = entry.find(',');
        if (separator != std::string::npos)
        {
            *id = atoi(&entry[separator + 1]);
            name->assign(entry.substr(0, separator));
            separator = entry.find(',', separator + 1);
            if (separator != std::string::npos)
            {
                *connected = atoi(&entry[separator + 1]) ? true : false;
            }
        }
    }
    return !name->empty();
}

int QHPeerConnection::GetResponseStatus(const std::string& response)
{
    int status = -1;
    size_t pos = response.find(' ');
    if (pos != std::string::npos)
    {
        status = atoi(&response[pos + 1]);
    }
    return status;
}

bool QHPeerConnection::ParseServerResponse(const std::string& response,
                                           size_t content_length,
                                           size_t* peer_id,
                                           size_t* eoh) {
    int status = GetResponseStatus(response.c_str());
    if (status != 200)
    {
        qDebug()<<"Received error from server"<<"++++++++++++++++++++++";
        CloseSocket();
        DeletePeerConnection();
        return false;
    }

    *eoh = response.find("\r\n\r\n");
    if (*eoh == std::string::npos)
    {
        return false;
    }

    *peer_id = -1;
    // See comment in peer_channel.cc for why we use the Pragma header.
    GetHeaderValue(response, *eoh, "\r\nPragma: ", peer_id);

    return true;
}

// PeerConnectionObserver implementation.
void QHPeerConnection::OnAddTrack(
        rtc::scoped_refptr<webrtc::RtpReceiverInterface> receiver,
        const std::vector<rtc::scoped_refptr<webrtc::MediaStreamInterface>>& streams)
{
    auto* track = reinterpret_cast<webrtc::MediaStreamTrackInterface*>(receiver->track().release());
    if (track->kind() == webrtc::MediaStreamTrackInterface::kVideoKind)
    {
        auto* video_track = static_cast<webrtc::VideoTrackInterface*>(track);
        video_track->AddOrUpdateSink(remote_render_, rtc::VideoSinkWants());
    }
    track->Release();
}

void QHPeerConnection::OnRemoveTrack(
        rtc::scoped_refptr<webrtc::RtpReceiverInterface> receiver)
{
    auto* track = reinterpret_cast<webrtc::MediaStreamTrackInterface*>(receiver->track().release());
    track->Release();
}

void QHPeerConnection::OnIceCandidate(const webrtc::IceCandidateInterface* candidate)
{
    Json::StyledWriter writer;
    Json::Value jmessage;

    jmessage[kCandidateSdpMidName] = candidate->sdp_mid();
    jmessage[kCandidateSdpMlineIndexName] = candidate->sdp_mline_index();
    std::string sdp;
    if (!candidate->ToString(&sdp))
    {
        qDebug()<<"Failed to serialize candidate"<<"++++++++++++++++++++++";
        return;
    }
    jmessage[kCandidateSdpName] = sdp;

    SendMessageToPeer(writer.write(jmessage));
}

// CreateSessionDescriptionObserver implementation.
void QHPeerConnection::OnSuccess(webrtc::SessionDescriptionInterface* desc)
{
    peer_connection_->SetLocalDescription(DummySetSessionDescriptionObserver::Create(), desc);

    std::string sdp;
    desc->ToString(&sdp);

    Json::StyledWriter writer;
    Json::Value jmessage;
    jmessage[kSessionDescriptionTypeName] = webrtc::SdpTypeToString(desc->GetType());
    jmessage[kSessionDescriptionSdpName] = sdp;

    SendMessageToPeer(writer.write(jmessage));
}

void QHPeerConnection::OnFailure(webrtc::RTCError error)
{
    qDebug()<<ToString(error.type())<<": "<<error.message()<<"++++++++++++++++++++++";
}

void QHPeerConnection::OnMessage(rtc::Message* msg)
{
    // ignore msg; there is currently only one supported message ("retry")
    DoConnect();
}

void QHPeerConnection::OnClose(rtc::AsyncSocket* socket, int err)
{
    socket->Close();

#ifdef WIN32
    if (err != WSAECONNREFUSED)
    {
#else
    if (err != ECONNREFUSED)
    {
#endif
        if (socket == hanging_socket_.get())
        {
            if (state_ == CONNECTED)
            {
                hanging_socket_->Close();
                hanging_socket_->Connect(server_address_);
            }
        }
        else
        {
            SendMessageToPeer("");
        }
    }
    else
    {
        if (socket == control_socket_.get())
        {
            // 当服务器未启动而客户端启动时，重试.
            qDebug()<<"Connection refused; retrying in 2 seconds"<<"++++++++++++++++++++++";
            rtc::Thread::Current()->PostDelayed(RTC_FROM_HERE, kReconnectDelay, this, 0);
        }
        else
        {
            // 当服务器退出时.
            CloseSocket();
            DeletePeerConnection();

            signalLogoutSucceed();
        }
    }
}

//GET /sign_in?Administrator@PC-20180621XWDZ HTTP/1.0\r\n\r\n
//GET /sign_out?peer_id=3 HTTP/1.0\r\n\r\n
void QHPeerConnection::OnControlConnect(rtc::AsyncSocket* socket)
{
    if(!onconnect_data_.empty())
    {
        socket->Send(onconnect_data_.c_str(), onconnect_data_.length());
        onconnect_data_.clear();
    }
}
//GET /wait?peer_id=3 HTTP/1.0\r\n\r\n
void QHPeerConnection::OnHangingConnect(rtc::AsyncSocket* socket)
{
    if(my_id_ != -1)
    {
        char buffer[1024];
        snprintf(buffer, sizeof(buffer), "GET /wait?peer_id=%i HTTP/1.0\r\n\r\n",my_id_);
        int len = static_cast<int>(strlen(buffer));
        socket->Send(buffer, len);
    }
}
//登录时获取peer列表.
//HTTP/1.1 200 Added
//Server: PeerConnectionTestServer/0.1
//Cache-Control: no-cache
//Connection: close
//Content-Type: text/plain
//Content-Length: 68
//Pragma: 5 // 自己的peer id，即my_id_
//Access-Control-Allow-Origin: *
//Access-Control-Allow-Credentials: true
//Access-Control-Allow-Methods: POST, GET, OPTIONS
//Access-Control-Allow-Headers: Content-Type, Content-Length, Connection, Cache-Control
//Access-Control-Expose-Headers: Content-Length

//Administrator@PC-20180621XWDZ,5,1
//Administrator@PC-20180621XWDZ,4,1 // 列表中其他peer的id，如果当前列表中有其他peer的话.
void QHPeerConnection::OnControlRead(rtc::AsyncSocket* socket)
{
    std::string control_data;
    size_t content_length = 0;
    if (ReadIntoBuffer(socket, &control_data, &content_length))
    {
        size_t peer_id = 0, eoh = 0;
        bool ok = ParseServerResponse(control_data, content_length, &peer_id, &eoh);
        if (ok)
        {
            // 第一次收到消息，获取my_id_,并更新peer列表.
            if (my_id_ == -1)
            {
                if(state_ == SIGNING_IN)
                {
                    my_id_ = static_cast<int>(peer_id);

                    // The body of the response will be a list of already connected peers.
                    if (content_length)
                    {
                        size_t pos = eoh + 4;
                        while (pos < control_data.size())
                        {
                            size_t eol = control_data.find('\n', pos);
                            if (eol == std::string::npos)
                            {
                                break;
                            }
                            int id = 0;
                            std::string name;
                            bool connected;
                            if (ParseEntry(control_data.substr(pos, eol - pos), &name, &id, &connected) && id != my_id_)
                            {
                                signalPeerConnected(id, QString::fromStdString(name));
                            }
                            pos = eol + 1;
                        }
                    }
                }

                signalLoginSucceed();
            }
            else if (state_ == SIGNING_OUT)
            {
                CloseSocket();
                DeletePeerConnection();

                signalLogoutSucceed();
            }
            else if (state_ == SIGNING_OUT_WAITING)
            {
                Logout();
            }
        }

        control_data.clear();

        if (state_ == SIGNING_IN)
        {
            if(hanging_socket_->GetState() == rtc::Socket::CS_CLOSED)
            {
                state_ = CONNECTED;
                hanging_socket_->Connect(server_address_);
            }
        }
    }
}

//HTTP/1.1 200 OK
//Server: PeerConnectionTestServer/0.1
//Cache-Control: no-cache
//Connection: close
//Content-Type: text/plain
//Content-Length: 35
//Pragma: 9 // 自己的peer id，即my_id_；或者是其他peer的id。当为其他peer的id时，收到的是sdp或candidate信息或bye message
//Access-Control-Allow-Origin: *
//Access-Control-Allow-Credentials: true
//Access-Control-Allow-Methods: POST, GET, OPTIONS
//Access-Control-Allow-Headers: Content-Type, Content-Length, Connection, Cache-Control
//Access-Control-Expose-Headers: Content-Length

//Administrator@PC-20180621XWDZ,10,1 // 当Pragma为my_id_时，用于获取新登录或退出的peer.最后的1标识新登录的peer，0标识退出的peer.
void QHPeerConnection::OnHangingRead(rtc::AsyncSocket* socket)
{
    std::string hanging_data;
    size_t content_length = 0;
    if (ReadIntoBuffer(socket, &hanging_data, &content_length))
    {
        size_t peer_id = 0, eoh = 0;
        bool ok = ParseServerResponse(hanging_data, content_length, &peer_id, &eoh);
        if (ok)
        {
            // Store the position where the body begins.
            size_t pos = eoh + 4;

            if (my_id_ == static_cast<int>(peer_id))
            {
                // A notification about a new member or a member that just disconnected.
                int id = 0;
                std::string name;
                bool connected = false;
                if (ParseEntry(hanging_data.substr(pos), &name, &id, &connected))
                {
                    if (connected)
                    {
                        signalPeerConnected(id, QString::fromStdString(name));
                    }
                    else
                    {
                        DeletePeerConnection();
                        signalPeerDisconnected(id);
                    }
                }
            }
            else
            {
                ReceiveMessageFromPeer(static_cast<int>(peer_id), hanging_data.substr(pos));
            }
        }

        hanging_data.clear();
    }

    if (hanging_socket_->GetState() == rtc::Socket::CS_CLOSED && state_ == CONNECTED)
    {
        hanging_socket_->Connect(server_address_);
    }
}

void QHPeerConnection::OnResolveResult(rtc::AsyncResolverInterface* resolver)
{
    if (resolver_->GetError() != 0)
    {
        resolver_->Destroy(false);
        resolver_ = nullptr;
        state_ = NOT_CONNECTED;
    }
    else
    {
        server_address_ = resolver_->address();
        DoConnect();
    }
}
