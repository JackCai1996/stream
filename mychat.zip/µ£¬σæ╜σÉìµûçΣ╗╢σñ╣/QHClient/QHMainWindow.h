#ifndef QHMAINWINDOW_H
#define QHMAINWINDOW_H

#include <QMainWindow>
#include <QMutex>
#include <QMutexLocker>
#include <QListWidgetItem>

#include "QHFrameEvent.h"
#include "QHAudioDevice.h"
#include "QHVideoCapturer.h"
#include "QHVideoRender.h"
#include "QHPeerConnection.h"

#include "rtc_base/third_party/sigslot/sigslot.h"

namespace Ui {
class QHMainWindow;
}

enum VideoFrameFrom
{
    kUnknow,
    kLocal,
    kRemote
};

class QHMainWindow : public QMainWindow , public sigslot::has_slots<>
{
    Q_OBJECT

public:
    explicit QHMainWindow(QWidget *parent = nullptr);
    ~QHMainWindow();

protected:
    void OnLocalVideoFrame(void *userData,const VideoFrame& videoFrame);
    void OnRemoteVideoFrame(void *userData,const VideoFrame& videoFrame);
    bool event(QEvent *event);

private:
    void postFrame(VideoFrameFrom frameFrom,void *userData,const VideoFrame& videoFrame);

private slots:
    void on_cameraComboBox_currentIndexChanged(int index);
    void on_resolutionComboBox_currentIndexChanged(int index);

    void on_recordingDeviceComboBox_currentIndexChanged(int index);
    void on_playoutDeviceComboBox_currentIndexChanged(int index);
    void on_microphoneVolumeSlider_valueChanged(int value);
    void on_speakerVolumeSlider_valueChanged(int value);

    void on_controlButton_clicked();

    void on_peerListWidget_itemDoubleClicked(QListWidgetItem *item);

    void slotPeerConnected(int id,const QString &name);
    void slotPeerDisconnected(int id);
    void slotLoginSucceed();
    void slotLogoutSucceed();

private:
    Ui::QHMainWindow *ui;

    std::unique_ptr<QHVideoRender> local_video_render_ = nullptr;
    std::unique_ptr<QHVideoRender> remote_video_render_ = nullptr;
    std::unique_ptr<QHVideoCapturer> video_capturer_ = nullptr;
    std::unique_ptr<QHAudioDevice> audio_device_ = nullptr;
    rtc::scoped_refptr<QHPeerConnection> peer_connection_ = nullptr;

    rtc::scoped_refptr<VideoFrameBuffer> last_frame_ = nullptr;
    std::unique_ptr<uint8_t[]> image_ = nullptr;
    std::unique_ptr<Frame> frame_ = nullptr;

    QMutex mutex_;
};

#endif // MAINWINDOW_H
