#ifndef QHFRAMEEVENT_H
#define QHFRAMEEVENT_H

#include <QEvent>

struct Frame
{
    int frameFrom;
    uint8_t *buffer;
    int width;
    int height;

    Frame()
    {
        frameFrom = 0;
        buffer = nullptr;
        width = 0;
        height = 0;
    }
};

class QHFrameEvent : public QEvent
{
public:
    explicit QHFrameEvent(Frame *frame);
    virtual ~QHFrameEvent();

public:
    static void postEvent(QObject *obj, Frame *frame);
    static QHFrameEvent *event(QEvent *e);

public:
    Frame *frame();

public:
    static int m_eventType;
    Frame *m_frame;
};

#endif // QHFRAMEEVENT_H
