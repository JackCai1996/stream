#include "QHVideoCapturer.h"

#include "absl/strings/match.h"
#include "absl/types/optional.h"

#include <QDebug>

QHVideoCapturer::QHVideoCapturer()
{
    device_info_.reset(VideoCaptureFactory::CreateDeviceInfo());
    number_of_devices_ = device_info_->NumberOfDevices();

    if(number_of_devices_>0)
    {
        device_available_ = true;
    }
    else
    {
        qDebug()<<"Can not find video devices"<<"+++++++++++++++++++++++++";
    }
}

QHVideoCapturer::~QHVideoCapturer()
{

}

QStringList QHVideoCapturer::GetVideoDeviceName()
{
     QStringList deviceNames;
     if(device_info_)
     {
         for(int i=0;i<number_of_devices_;i++)
         {
             char device_name[256];
             char unique_name[256];
             int result=device_info_->GetDeviceName(i, device_name, 256, unique_name, 256);
             if(result==0)
             {
                 deviceNames.append(QString(device_name));
             }
         }
     }
     return deviceNames;
}

QStringList QHVideoCapturer::GetSupportedCapability()
{
    QStringList list;
    if(video_capture_)
    {
        int number_of_capabilities = device_info_->NumberOfCapabilities(video_capture_->CurrentDeviceName());
        for(int i=0;i<number_of_capabilities;i++)
        {
            VideoCaptureCapability capability;
            device_info_->GetCapability(video_capture_->CurrentDeviceName(), i, capability);
            QString str=QString("%1 * %2").arg(capability.width).arg(capability.height);
            list.append(str);
        }
    }
    return list;
}

void QHVideoCapturer::SetCurrentCapability(int index)
{
    current_capability_ = index;
}

void QHVideoCapturer::OpenVideoCaptureDevice(int index)
{
    if(device_info_)
    {
        char device_name[256];
        char unique_name[256];
        int result = device_info_->GetDeviceName(index, device_name, 256, unique_name, 256);
        if(result == 0)
        {
            rtc::scoped_refptr<VideoCaptureModule> module(VideoCaptureFactory::Create(unique_name));
            if (module)
            {
                video_capture_ = module;
            }
        }
    }
}

void QHVideoCapturer::StartCapture()
{
    StopCapture();

    if(video_capture_)
    {
        VideoCaptureCapability capability;
        device_info_->GetCapability(video_capture_->CurrentDeviceName(), current_capability_, capability);

        int result=video_capture_->StartCapture(capability);
        if(result == 0)
        {
            bool started=video_capture_->CaptureStarted();
            if(started)
            {
                VideoCaptureCapability resulting_capability;
                result=video_capture_->CaptureSettings(resulting_capability);
                if(result == 0)
                {
                    if(capability.width == resulting_capability.width
                            && capability.height ==resulting_capability.height)
                    {
                        video_capture_->RegisterCaptureDataCallback(this);
                        qDebug()<<"StartCapture succeed"<<"++++++++++++++++++++++++++";
                    }
                }
            }
        }
    }
}

void QHVideoCapturer::StopCapture()
{
    if(video_capture_)
    {
        bool started=video_capture_->CaptureStarted();
        if(started)
        {
            video_capture_->StopCapture();

            video_capture_->RegisterCaptureDataCallback(nullptr);

            qDebug()<<"StopCapture succeed"<<"++++++++++++++++++++++++++";
        }
    }
}

bool QHVideoCapturer::DeviceAvailable()
{
    return device_available_;
}

void QHVideoCapturer::UpdateVideoAdapter()
{
    video_adapter_.OnSinkWants(broadcaster_.wants());
}

void QHVideoCapturer::AddOrUpdateSink(rtc::VideoSinkInterface<VideoFrame>* sink, const rtc::VideoSinkWants& wants)
{
    MutexLock lock(&mutex_);

    broadcaster_.AddOrUpdateSink(sink, wants);
    UpdateVideoAdapter();
}

void QHVideoCapturer::RemoveSink(rtc::VideoSinkInterface<VideoFrame>* sink)
{
    MutexLock lock(&mutex_);

    broadcaster_.RemoveSink(sink);
    UpdateVideoAdapter();
}

void QHVideoCapturer::OnFrame(const VideoFrame& video_frame)
{
    MutexLock lock(&mutex_);

    IncomingCapturedFrame(video_frame);
}

void QHVideoCapturer::IncomingCapturedFrame(const VideoFrame& video_frame)
{
    MutexLock lock(&mutex_);

    int cropped_width = 0;
    int cropped_height = 0;
    int out_width = 0;
    int out_height = 0;

    if (!video_adapter_.AdaptFrameResolution(
                video_frame.width(),
                video_frame.height(),
                video_frame.timestamp_us() * 1000,
                &cropped_width,
                &cropped_height,
                &out_width,
                &out_height))
    {
        // Drop frame in order to respect frame rate constraint.
        return;
    }

    if (out_height != video_frame.height() || out_width != video_frame.width())
    {
        // Video adapter has requested a down-scale. Allocate a new buffer and
        // return scaled version.
        // For simplicity, only scale here without cropping.
        rtc::scoped_refptr<I420Buffer> scaled_buffer = I420Buffer::Create(out_width, out_height);
        scaled_buffer->ScaleFrom(*video_frame.video_frame_buffer()->ToI420());
        VideoFrame::Builder new_frame_builder =
                VideoFrame::Builder()
                .set_video_frame_buffer(scaled_buffer)
                .set_rotation(kVideoRotation_0)
                .set_timestamp_us(video_frame.timestamp_us())
                .set_id(video_frame.id());

        if (video_frame.has_update_rect())
        {
            VideoFrame::UpdateRect new_rect = video_frame.update_rect().ScaleWithFrame(
                        video_frame.width(),
                        video_frame.height(),
                        0,
                        0,
                        video_frame.width(),
                        video_frame.height(),
                        out_width, out_height);
            new_frame_builder.set_update_rect(new_rect);
        }

        broadcaster_.OnFrame(new_frame_builder.build());
    }
    else
    {
        // No adaptations needed, just return the frame as is.
        broadcaster_.OnFrame(video_frame);
    }
}
