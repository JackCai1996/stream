#ifndef QHCAPTURERTRACKSOURCE_H
#define QHCAPTURERTRACKSOURCE_H

#include <QHVideoCapturer.h>

#include "pc/video_track_source.h"

using namespace webrtc;

class QHCapturerTrackSource : public VideoTrackSource
{
public:
     QHCapturerTrackSource(QHVideoCapturer *capturer);
     ~QHCapturerTrackSource();

private:
    rtc::VideoSourceInterface<webrtc::VideoFrame>* source() override;

private:
    QHVideoCapturer *capturer_;
};

#endif // QHCAPTURERTRACKSOURCE_H
