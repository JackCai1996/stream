<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>QHMainWindow</name>
    <message>
        <location filename="QHMainWindow.ui" line="97"/>
        <source>摄像头：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="62"/>
        <source>分辨率：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="14"/>
        <source>QHClient</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="136"/>
        <source>麦克风：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="171"/>
        <source>扬声器：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="206"/>
        <source>麦克风音量：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="247"/>
        <source>扬声器音量：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="295"/>
        <source>登录</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="308"/>
        <source>localhost</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="315"/>
        <source>服务器Port：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="361"/>
        <source>服务器IP：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="381"/>
        <source>8888</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="368"/>
        <source>编码格式：</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QHMainWindow.ui" line="354"/>
        <source>解码格式：</source>
        <translation></translation>
    </message>
    <message>
        <source>stop</source>
        <translation type="vanished">停止</translation>
    </message>
    <message>
        <source>start</source>
        <translation type="vanished">开始</translation>
    </message>
    <message>
        <location filename="QHMainWindow.cpp" line="273"/>
        <source>logout</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="QHMainWindow.cpp" line="277"/>
        <source>login</source>
        <translation>登录</translation>
    </message>
</context>
</TS>
