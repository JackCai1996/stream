/********************************************************************************
** Form generated from reading UI file 'QHMainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QHMAINWINDOW_H
#define UI_QHMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QHMainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout_4;
    QLabel *remoteVideoLabel;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout_2;
    QLabel *label_12;
    QComboBox *resolutionComboBox;
    QLabel *label_11;
    QComboBox *cameraComboBox;
    QGridLayout *gridLayout_3;
    QLabel *label_2;
    QComboBox *recordingDeviceComboBox;
    QLabel *label_3;
    QComboBox *playoutDeviceComboBox;
    QLabel *label_4;
    QSlider *microphoneVolumeSlider;
    QLabel *label_5;
    QSlider *speakerVolumeSlider;
    QGridLayout *gridLayout;
    QLineEdit *serverIPLineEdit;
    QLabel *label_7;
    QLabel *label_6;
    QLineEdit *serverPortLineEdit;
    QPushButton *controlButton;
    QListWidget *peerListWidget;
    QLabel *localVideoLabel;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QHMainWindow)
    {
        if (QHMainWindow->objectName().isEmpty())
            QHMainWindow->setObjectName(QString::fromUtf8("QHMainWindow"));
        QHMainWindow->resize(886, 723);
        centralWidget = new QWidget(QHMainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout_4 = new QGridLayout(centralWidget);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        remoteVideoLabel = new QLabel(centralWidget);
        remoteVideoLabel->setObjectName(QString::fromUtf8("remoteVideoLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(remoteVideoLabel->sizePolicy().hasHeightForWidth());
        remoteVideoLabel->setSizePolicy(sizePolicy);
        remoteVideoLabel->setMinimumSize(QSize(600, 500));
        remoteVideoLabel->setMaximumSize(QSize(16777215, 16777215));
        remoteVideoLabel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        remoteVideoLabel->setFrameShape(QFrame::Box);

        gridLayout_4->addWidget(remoteVideoLabel, 0, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy1);

        gridLayout_2->addWidget(label_12, 1, 0, 1, 1);

        resolutionComboBox = new QComboBox(centralWidget);
        resolutionComboBox->setObjectName(QString::fromUtf8("resolutionComboBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(resolutionComboBox->sizePolicy().hasHeightForWidth());
        resolutionComboBox->setSizePolicy(sizePolicy2);
        resolutionComboBox->setMinimumSize(QSize(200, 30));
        resolutionComboBox->setMaximumSize(QSize(200, 30));

        gridLayout_2->addWidget(resolutionComboBox, 1, 1, 1, 2);

        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        sizePolicy1.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy1);

        gridLayout_2->addWidget(label_11, 0, 0, 1, 1);

        cameraComboBox = new QComboBox(centralWidget);
        cameraComboBox->setObjectName(QString::fromUtf8("cameraComboBox"));
        sizePolicy2.setHeightForWidth(cameraComboBox->sizePolicy().hasHeightForWidth());
        cameraComboBox->setSizePolicy(sizePolicy2);
        cameraComboBox->setMinimumSize(QSize(200, 30));
        cameraComboBox->setMaximumSize(QSize(200, 30));

        gridLayout_2->addWidget(cameraComboBox, 0, 1, 1, 2);


        verticalLayout->addLayout(gridLayout_2);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(label_2, 0, 0, 1, 1);

        recordingDeviceComboBox = new QComboBox(centralWidget);
        recordingDeviceComboBox->setObjectName(QString::fromUtf8("recordingDeviceComboBox"));
        sizePolicy2.setHeightForWidth(recordingDeviceComboBox->sizePolicy().hasHeightForWidth());
        recordingDeviceComboBox->setSizePolicy(sizePolicy2);
        recordingDeviceComboBox->setMinimumSize(QSize(200, 30));
        recordingDeviceComboBox->setMaximumSize(QSize(200, 30));

        gridLayout_3->addWidget(recordingDeviceComboBox, 0, 1, 1, 2);

        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        sizePolicy1.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(label_3, 1, 0, 1, 1);

        playoutDeviceComboBox = new QComboBox(centralWidget);
        playoutDeviceComboBox->setObjectName(QString::fromUtf8("playoutDeviceComboBox"));
        sizePolicy2.setHeightForWidth(playoutDeviceComboBox->sizePolicy().hasHeightForWidth());
        playoutDeviceComboBox->setSizePolicy(sizePolicy2);
        playoutDeviceComboBox->setMinimumSize(QSize(200, 30));
        playoutDeviceComboBox->setMaximumSize(QSize(30, 30));

        gridLayout_3->addWidget(playoutDeviceComboBox, 1, 1, 1, 2);

        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        sizePolicy1.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(label_4, 2, 0, 1, 2);

        microphoneVolumeSlider = new QSlider(centralWidget);
        microphoneVolumeSlider->setObjectName(QString::fromUtf8("microphoneVolumeSlider"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(microphoneVolumeSlider->sizePolicy().hasHeightForWidth());
        microphoneVolumeSlider->setSizePolicy(sizePolicy3);
        microphoneVolumeSlider->setMinimumSize(QSize(180, 0));
        microphoneVolumeSlider->setMaximumSize(QSize(180, 16777215));
        microphoneVolumeSlider->setMaximum(255);
        microphoneVolumeSlider->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(microphoneVolumeSlider, 2, 2, 1, 1);

        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        sizePolicy1.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy1);

        gridLayout_3->addWidget(label_5, 3, 0, 1, 2);

        speakerVolumeSlider = new QSlider(centralWidget);
        speakerVolumeSlider->setObjectName(QString::fromUtf8("speakerVolumeSlider"));
        sizePolicy3.setHeightForWidth(speakerVolumeSlider->sizePolicy().hasHeightForWidth());
        speakerVolumeSlider->setSizePolicy(sizePolicy3);
        speakerVolumeSlider->setMinimumSize(QSize(180, 0));
        speakerVolumeSlider->setMaximumSize(QSize(180, 16777215));
        speakerVolumeSlider->setMaximum(255);
        speakerVolumeSlider->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(speakerVolumeSlider, 3, 2, 1, 1);


        verticalLayout->addLayout(gridLayout_3);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        serverIPLineEdit = new QLineEdit(centralWidget);
        serverIPLineEdit->setObjectName(QString::fromUtf8("serverIPLineEdit"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(serverIPLineEdit->sizePolicy().hasHeightForWidth());
        serverIPLineEdit->setSizePolicy(sizePolicy4);
        serverIPLineEdit->setFocusPolicy(Qt::ClickFocus);

        gridLayout->addWidget(serverIPLineEdit, 0, 1, 1, 1);

        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 1, 0, 1, 1);

        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 0, 0, 1, 1);

        serverPortLineEdit = new QLineEdit(centralWidget);
        serverPortLineEdit->setObjectName(QString::fromUtf8("serverPortLineEdit"));
        sizePolicy4.setHeightForWidth(serverPortLineEdit->sizePolicy().hasHeightForWidth());
        serverPortLineEdit->setSizePolicy(sizePolicy4);
        serverPortLineEdit->setFocusPolicy(Qt::ClickFocus);

        gridLayout->addWidget(serverPortLineEdit, 1, 1, 1, 1);

        controlButton = new QPushButton(centralWidget);
        controlButton->setObjectName(QString::fromUtf8("controlButton"));
        controlButton->setEnabled(false);
        controlButton->setMinimumSize(QSize(0, 30));

        gridLayout->addWidget(controlButton, 2, 0, 1, 2);


        verticalLayout->addLayout(gridLayout);

        peerListWidget = new QListWidget(centralWidget);
        peerListWidget->setObjectName(QString::fromUtf8("peerListWidget"));
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(peerListWidget->sizePolicy().hasHeightForWidth());
        peerListWidget->setSizePolicy(sizePolicy5);

        verticalLayout->addWidget(peerListWidget);

        localVideoLabel = new QLabel(centralWidget);
        localVideoLabel->setObjectName(QString::fromUtf8("localVideoLabel"));
        sizePolicy3.setHeightForWidth(localVideoLabel->sizePolicy().hasHeightForWidth());
        localVideoLabel->setSizePolicy(sizePolicy3);
        localVideoLabel->setMinimumSize(QSize(260, 210));
        localVideoLabel->setMaximumSize(QSize(260, 210));
        localVideoLabel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        localVideoLabel->setFrameShape(QFrame::Box);

        verticalLayout->addWidget(localVideoLabel);


        gridLayout_4->addLayout(verticalLayout, 0, 1, 1, 1);

        QHMainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QHMainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 886, 22));
        QHMainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QHMainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        QHMainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QHMainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        QHMainWindow->setStatusBar(statusBar);

        retranslateUi(QHMainWindow);

        QMetaObject::connectSlotsByName(QHMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *QHMainWindow)
    {
        QHMainWindow->setWindowTitle(QApplication::translate("QHMainWindow", "QHClient", nullptr));
        remoteVideoLabel->setText(QString());
        label_12->setText(QApplication::translate("QHMainWindow", "\345\210\206\350\276\250\347\216\207\357\274\232", nullptr));
        label_11->setText(QApplication::translate("QHMainWindow", "\346\221\204\345\203\217\345\244\264\357\274\232", nullptr));
        label_2->setText(QApplication::translate("QHMainWindow", "\351\272\246\345\205\213\351\243\216\357\274\232", nullptr));
        label_3->setText(QApplication::translate("QHMainWindow", "\346\211\254\345\243\260\345\231\250\357\274\232", nullptr));
        label_4->setText(QApplication::translate("QHMainWindow", "\351\272\246\345\205\213\351\243\216\351\237\263\351\207\217\357\274\232", nullptr));
        label_5->setText(QApplication::translate("QHMainWindow", "\346\211\254\345\243\260\345\231\250\351\237\263\351\207\217\357\274\232", nullptr));
        serverIPLineEdit->setText(QApplication::translate("QHMainWindow", "localhost", nullptr));
        label_7->setText(QApplication::translate("QHMainWindow", "\346\234\215\345\212\241\345\231\250Port\357\274\232", nullptr));
        label_6->setText(QApplication::translate("QHMainWindow", "\346\234\215\345\212\241\345\231\250IP\357\274\232", nullptr));
        serverPortLineEdit->setText(QApplication::translate("QHMainWindow", "8888", nullptr));
        controlButton->setText(QApplication::translate("QHMainWindow", "\347\231\273\345\275\225", nullptr));
        localVideoLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class QHMainWindow: public Ui_QHMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QHMAINWINDOW_H
