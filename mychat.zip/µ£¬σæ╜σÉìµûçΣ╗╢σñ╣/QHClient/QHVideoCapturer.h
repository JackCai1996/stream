#ifndef QVIDEOCAPTURER_H
#define QVIDEOCAPTURER_H

#include <QStringList>

#include "api/scoped_refptr.h"
#include "api/video/i420_buffer.h"
#include "api/video/video_frame.h"
#include "api/video/video_source_interface.h"
#include "media/base/codec.h"
#include "media/base/media_constants.h"
#include "media/base/h264_profile_level_id.h"
#include "media/base/video_adapter.h"
#include "media/base/video_broadcaster.h"
#include "rtc_base/synchronization/mutex.h"
#include "modules/video_capture/video_capture.h"
#include "modules/video_capture/video_capture_factory.h"

using namespace webrtc;

class QHVideoCapturer : public rtc::VideoSourceInterface<webrtc::VideoFrame>,
                        public rtc::VideoSinkInterface<webrtc::VideoFrame>
{
public:
    explicit QHVideoCapturer();
    virtual ~QHVideoCapturer();

public:
    QStringList GetVideoDeviceName();
    QStringList GetSupportedCapability();

    void SetCurrentCapability(int index);
    void OpenVideoCaptureDevice(int index);
    void StartCapture();
    void StopCapture();

    bool DeviceAvailable();

private:
    void UpdateVideoAdapter();

protected:
    // VideoSourceInterface functions override
    void AddOrUpdateSink(rtc::VideoSinkInterface<VideoFrame>* sink, const rtc::VideoSinkWants& wants) override;
    void RemoveSink(rtc::VideoSinkInterface<VideoFrame>* sink) override;
    // VideoSinkInterface functions override
    void OnFrame(const VideoFrame& video_frame) override;

protected:
    void IncomingCapturedFrame(const VideoFrame& video_frame);

private:
    Mutex mutex_;
    rtc::VideoBroadcaster broadcaster_;
    cricket::VideoAdapter video_adapter_;

    std::unique_ptr<VideoCaptureModule::DeviceInfo> device_info_;
    rtc::scoped_refptr<VideoCaptureModule> video_capture_;

    int current_capability_ = 0;
    unsigned int number_of_devices_ = 0;
    bool device_available_ = false;
};

#endif // QVIDEOCAPTURER_H
