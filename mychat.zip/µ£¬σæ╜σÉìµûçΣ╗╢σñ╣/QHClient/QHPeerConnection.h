#ifndef QHPEERCONNECTION_H
#define QHPEERCONNECTION_H

#include "api/scoped_refptr.h"
#include "api/media_stream_interface.h"
#include "api/peer_connection_interface.h"
#include "rtc_base/net_helpers.h"
#include "rtc_base/physical_socket_server.h"
#include "rtc_base/third_party/sigslot/sigslot.h"

#ifdef WIN32
#include "rtc_base/win32_socket_server.h"
#endif

#include <QDebug>

using namespace webrtc;

class QHVideoRender;
class QHVideoCapturer;
class QHAudioDevice;

enum ConnectionState {
    NOT_CONNECTED,
    RESOLVING,
    SIGNING_IN,
    CONNECTED,
    SIGNING_OUT_WAITING,
    SIGNING_OUT,
};

class DummySetSessionDescriptionObserver : public webrtc::SetSessionDescriptionObserver
{
public:
    static DummySetSessionDescriptionObserver* Create()
    {
        return new rtc::RefCountedObject<DummySetSessionDescriptionObserver>();
    }
    virtual void OnSuccess() {}
    virtual void OnFailure(webrtc::RTCError error)
    {
        qDebug()<< ToString(error.type()) << ": " << error.message()<<"++++++++++++++++++++++";
    }
};

class QHPeerConnection : public QObject,
                         public PeerConnectionObserver,
                         public CreateSessionDescriptionObserver,
                         public rtc::MessageHandler,
                         public sigslot::has_slots<>
{
    Q_OBJECT

public:
    QHPeerConnection(QHVideoRender *local_render,QHVideoRender *remote_render,QHVideoCapturer *video_capturer,QHAudioDevice *audio_device);
    ~QHPeerConnection();

public:
    void ConnectToPeer(int peer_id);
    void DisconnectFromPeer();

    void Login(const std::string& server, int port);
    bool Logout();
    bool IsLogined();

private:
    bool InitializePeerConnection();
    bool CreatePeerConnection(bool dtls);
    void DeletePeerConnection();
    void AddTracks();

    rtc::AsyncSocket* CreateSocket(int family);
    bool ConnectControlSocket();
    void CloseSocket();
    void ConnectToServer(const std::string& server, int port, const std::string& client_name);
    void DoConnect();

    void SendMessageToPeer(const std::string& message);
    bool DoSend(int peer_id, const std::string& message);
    bool IsSendingMessage();
    void ReceiveMessageFromPeer(int peer_id, const std::string& message);

    std::string GetPeerName();
    std::string GetEnvVarOrDefault(const char* env_var_name,const char* default_value);
    // Returns true if the whole response has been read.
    bool ReadIntoBuffer(rtc::AsyncSocket* socket,
                        std::string* data,
                        size_t* content_length);
    // Quick and dirty support for parsing HTTP header values.
    bool GetHeaderValue(const std::string& data,
                        size_t eoh,
                        const char* header_pattern,
                        size_t* value);
    bool GetHeaderValue(const std::string& data,
                        size_t eoh,
                        const char* header_pattern,
                        std::string* value);

    // Parses a single line entry(a peer)in the form "<name>,<id>,<connected>"
    bool ParseEntry(const std::string& entry,
                    std::string* name,
                    int* id,
                    bool* connected);
    int GetResponseStatus(const std::string& response);
    bool ParseServerResponse(const std::string& response,
                             size_t content_length,
                             size_t* peer_id,
                             size_t* eoh);

protected:
    // PeerConnectionObserver implementation.
    void OnSignalingChange(
            webrtc::PeerConnectionInterface::SignalingState new_state) override {}
    void OnAddTrack(
            rtc::scoped_refptr<webrtc::RtpReceiverInterface> receiver,
            const std::vector<rtc::scoped_refptr<webrtc::MediaStreamInterface>>& streams) override;
    void OnRemoveTrack(
            rtc::scoped_refptr<webrtc::RtpReceiverInterface> receiver) override;
    void OnDataChannel(
            rtc::scoped_refptr<webrtc::DataChannelInterface> channel) override {}
    void OnRenegotiationNeeded() override {}
    void OnIceConnectionChange(
            webrtc::PeerConnectionInterface::IceConnectionState new_state) override {}
    void OnIceGatheringChange(
            webrtc::PeerConnectionInterface::IceGatheringState new_state) override {}
    void OnIceCandidate(const webrtc::IceCandidateInterface* candidate) override;
    void OnIceConnectionReceivingChange(bool receiving) override {}

    // CreateSessionDescriptionObserver implementation.
    void OnSuccess(webrtc::SessionDescriptionInterface* desc) override;
    void OnFailure(webrtc::RTCError error) override;

    // implements the MessageHandler interface
    void OnMessage(rtc::Message* msg) override;

    // webrtc slots
    void OnClose(rtc::AsyncSocket* socket, int err);
    void OnControlConnect(rtc::AsyncSocket* socket);
    void OnHangingConnect(rtc::AsyncSocket* socket);
    void OnControlRead(rtc::AsyncSocket* socket);
    void OnHangingRead(rtc::AsyncSocket* socket);
    void OnResolveResult(rtc::AsyncResolverInterface* resolver);

private:
    QHVideoRender *local_render_ = nullptr;
    QHVideoRender *remote_render_ = nullptr;
    QHVideoCapturer *video_capturer_ = nullptr;
    QHAudioDevice *audio_device_ = nullptr;

    int peer_id_ = -1;
    rtc::scoped_refptr<PeerConnectionInterface> peer_connection_ = nullptr;
    rtc::scoped_refptr<PeerConnectionFactoryInterface> peer_connection_factory_ = nullptr;

    rtc::SocketAddress server_address_;
    rtc::AsyncResolver* resolver_ = nullptr;
    // control_socket_用于发送SIGNING_IN、SIGNING_OUT、bye和sdp等信息，
    // hanging_socket_用于接收其他peer的SIGNING_IN、SIGNING_OUT、bye和sdp等信息.
    // control_socket_和hanging_socket_都模拟http的短连接，发送或接收数据后会马上断开.
    // 与control_socket_不同的是hanging_socket_发送"GET /wait?peer_id=%i HTTP/1.0\r\n\r\n"后并不会立即断开，
    // 而是在收到服务端数据后断开，并且断开后会立即重连并发送"GET /wait?peer_id=%i HTTP/1.0\r\n\r\n".
    std::unique_ptr<rtc::AsyncSocket> control_socket_ = nullptr;
    std::unique_ptr<rtc::AsyncSocket> hanging_socket_ = nullptr;

    ConnectionState state_ = NOT_CONNECTED;
    int my_id_ = -1;

    std::string onconnect_data_;
    std::string client_name_;
    std::deque<std::string*> pending_messages_;

signals:
    void signalPeerConnected(int id,const QString &name);
    void signalPeerDisconnected(int id);
    void signalLoginSucceed();
    void signalLogoutSucceed();
};

#endif // QHPEERCONNECTION_H
