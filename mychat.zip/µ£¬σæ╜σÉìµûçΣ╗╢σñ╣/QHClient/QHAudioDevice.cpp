#include "QHAudioDevice.h"

#include <QDebug>

QHAudioDevice::QHAudioDevice()
{
    task_queue_factory_ = CreateDefaultTaskQueueFactory();
    audio_device_ = CreateAudioDevice();

    if(audio_device_)
    {
        AudioDeviceModule::AudioLayer audio_layer;
        int got_platform_audio_layer = audio_device_->ActiveAudioLayer(&audio_layer);
        // First, ensure that a valid audio layer can be activated.
        if(got_platform_audio_layer==0)
        {
            audio_device_->Init();

            const int16_t num_playout_devices = audio_device_->PlayoutDevices();
            const int16_t num_record_devices = audio_device_->RecordingDevices();
            if(num_playout_devices > 0 && num_record_devices > 0)
            {
                 device_available_ = true;
            }
            else
            {
                if(num_playout_devices==0)
                {
                    qDebug()<<"Can not find palyout devices"<<"+++++++++++++++++++++++++";
                }
                if(num_record_devices==0)
                {
                    qDebug()<<"Can not find record devices"<<"+++++++++++++++++++++++++";
                }
            }
        }
    }
}

QHAudioDevice::~QHAudioDevice()
{

}

QStringList QHAudioDevice::GetPlayoutDeviceName()
{
    QStringList deviceNames;
    if(audio_device_)
    {
        char device_name[kAdmMaxDeviceNameSize];
        char unique_id[kAdmMaxGuidSize];
        int num_devices = audio_device_->PlayoutDevices();

        for (int i = 0; i < num_devices; ++i)
        {
            audio_device_->PlayoutDeviceName(i, device_name, unique_id);
            deviceNames.append(QString(device_name));
        }
    }

    return deviceNames;
}

QStringList QHAudioDevice::GetRecordingDeviceName()
{
    QStringList deviceNames;
    if(audio_device_)
    {
        char device_name[kAdmMaxDeviceNameSize];
        char unique_id[kAdmMaxGuidSize];
        int num_devices = audio_device_->RecordingDevices();

        for (int i = 0; i < num_devices; ++i)
        {
            audio_device_->RecordingDeviceName(i, device_name, unique_id);
            deviceNames.append(QString(device_name));
        }
    }
    return deviceNames;
}

int QHAudioDevice::GetMicrophoneVolume()
{
    if(audio_device_)
    {
        uint32_t volume = 0;
        int result = audio_device_->MicrophoneVolume(&volume);
        if(result==0)
        {
            return volume;
        }
    }
    return 0;
}

int QHAudioDevice::GetSpeakerVolume()
{
    if(audio_device_)
    {
        uint32_t volume = 0;
        int result = audio_device_->SpeakerVolume(&volume);
        if(result==0)
        {
            return volume;
        }
    }
    return 0;
}

void QHAudioDevice::SetPlayoutDevice(int index)
{
    if(audio_device_)
    {
        audio_device_->SetPlayoutDevice(index);

        // 下面代码可以根据不同设备获取对应的音量.
        audio_device_->InitSpeaker();
        bool stereo_playout = false;
        audio_device_->StereoPlayoutIsAvailable(&stereo_playout);
        audio_device_->SetStereoPlayout(stereo_playout);
    }
}

void QHAudioDevice::SetRecordingDevice(int index)
{
    if(audio_device_)
    {
        audio_device_->SetRecordingDevice(index);

        // 下面代码可以根据不同设备获取对应的音量.
        audio_device_->InitMicrophone();
        // Avoid asking for input stereo support and always record in mono
        // since asking can cause issues in combination with remote desktop.
        // See https://bugs.chromium.org/p/webrtc/issues/detail?id=7397 for
        // details.
        audio_device_->SetStereoRecording(false);
    }
}

void QHAudioDevice::SetMicrophoneVolume(int value)
{
    if(audio_device_)
    {
        audio_device_->SetMicrophoneVolume(value);
    }
}

void QHAudioDevice::SetSpeakerVolume(int value)
{
    if(audio_device_)
    {
        audio_device_->SetSpeakerVolume(value);
    }
}

bool QHAudioDevice::DeviceAvailable()
{
    return device_available_;
}

rtc::scoped_refptr<AudioDeviceModule> QHAudioDevice::Device()
{
    return audio_device_;
}

rtc::scoped_refptr<AudioDeviceModule> QHAudioDevice::CreateAudioDevice()
{
    if(task_queue_factory_)
    {
        return AudioDeviceModule::Create(AudioDeviceModule::kPlatformDefaultAudio,
                                                task_queue_factory_.get());
    }
    return nullptr;
}
