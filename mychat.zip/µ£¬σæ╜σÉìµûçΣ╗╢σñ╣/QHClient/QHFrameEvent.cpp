#include "QHFrameEvent.h"
#include <QCoreApplication>

int QHFrameEvent::m_eventType = QEvent::registerEventType();

QHFrameEvent::QHFrameEvent(Frame *frame)
    : QEvent(static_cast<Type>(m_eventType))
{
    m_frame=frame;
}

QHFrameEvent::~QHFrameEvent()
{

}

void QHFrameEvent::postEvent(QObject *obj, Frame *frame)
{
    if (qApp && obj)
    {
        qApp->postEvent(obj, new QHFrameEvent(frame));
    }
}

QHFrameEvent *QHFrameEvent::event(QEvent *e)
{
    return (e && (e->type() == m_eventType)) ? reinterpret_cast<QHFrameEvent *>(e) : nullptr;
}

Frame *QHFrameEvent::frame()
{
    return m_frame;
}
