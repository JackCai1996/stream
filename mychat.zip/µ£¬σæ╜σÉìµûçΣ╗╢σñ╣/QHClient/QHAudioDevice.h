#ifndef QHAUDIODEVICE_H
#define QHAUDIODEVICE_H

#include "api/scoped_refptr.h"
#include "api/task_queue/default_task_queue_factory.h"
#include "modules/audio_device/include/audio_device.h"

#include <QStringList>

using namespace webrtc;

class QHAudioDevice
{
public:
    QHAudioDevice();
    ~QHAudioDevice();

public:
    QStringList GetPlayoutDeviceName();
    QStringList GetRecordingDeviceName();
    int GetMicrophoneVolume();
    int GetSpeakerVolume();
    void SetPlayoutDevice(int index);
    void SetRecordingDevice(int index);
    void SetMicrophoneVolume(int value);
    void SetSpeakerVolume(int value);

    bool DeviceAvailable();

    rtc::scoped_refptr<AudioDeviceModule> Device();

private:
    rtc::scoped_refptr<AudioDeviceModule> CreateAudioDevice();

private:
    std::unique_ptr<TaskQueueFactory> task_queue_factory_ = nullptr;
    rtc::scoped_refptr<AudioDeviceModule> audio_device_ = nullptr;

    bool device_available_ = false;
};

#endif // QHAUDIODEVICE_H
