#ifndef QHVIDEORENDER_H
#define QHVIDEORENDER_H

#include "api/scoped_refptr.h"
#include "api/video/i420_buffer.h"
#include "api/video/video_frame.h"
#include "modules/video_capture/video_capture.h"
#include "rtc_base/synchronization/mutex.h"
#include "rtc_base/third_party/sigslot/sigslot.h"
#include "common_video/libyuv/include/webrtc_libyuv.h"
#include "libyuv.h"

using namespace webrtc;

class QHVideoRender : public rtc::VideoSinkInterface<webrtc::VideoFrame>
{
public:
    QHVideoRender(void *userData);
    ~QHVideoRender();

    void OnFrame(const VideoFrame& videoFrame) override;

public:
    sigslot::signal2<void *,const VideoFrame&> SignalVideoFrame;

private:
    Mutex mutex_;

    void *user_data_ = nullptr;
};

#endif // QHVIDEORENDER_H
