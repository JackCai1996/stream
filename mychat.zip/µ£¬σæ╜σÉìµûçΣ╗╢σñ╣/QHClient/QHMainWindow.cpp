﻿#include "QHMainWindow.h"
#include "ui_QHMainWindow.h"

#include <QDebug>
#include <combaseapi.h>

#include "rtc_base/logging.h"
#include "common_video/libyuv/include/webrtc_libyuv.h"
#include "libyuv.h"

QHMainWindow::QHMainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::QHMainWindow)
{
    ui->setupUi(this);

    CoUninitialize();

    rtc::LogMessage::LogToDebug(rtc::LS_INFO);
    // Add extra logging fields here if needed for debugging.
    rtc::LogMessage::LogTimestamps();
    rtc::LogMessage::LogThreads();

    local_video_render_.reset(new QHVideoRender(this));
    remote_video_render_.reset(new QHVideoRender(this));
    video_capturer_.reset(new QHVideoCapturer());
    audio_device_.reset(new QHAudioDevice());
    peer_connection_= new rtc::RefCountedObject<QHPeerConnection>(
                local_video_render_.get(),
                remote_video_render_.get(),
                video_capturer_.get(),
                audio_device_.get());

    connect(peer_connection_,&QHPeerConnection::signalPeerConnected,this,&QHMainWindow::slotPeerConnected,Qt::QueuedConnection);
    connect(peer_connection_,&QHPeerConnection::signalPeerDisconnected,this,&QHMainWindow::slotPeerDisconnected,Qt::QueuedConnection);
    connect(peer_connection_,&QHPeerConnection::signalLoginSucceed,this,&QHMainWindow::slotLoginSucceed,Qt::QueuedConnection);
    connect(peer_connection_,&QHPeerConnection::signalLogoutSucceed,this,&QHMainWindow::slotLogoutSucceed,Qt::QueuedConnection);


    local_video_render_->SignalVideoFrame.connect(this,&QHMainWindow::OnLocalVideoFrame);
    remote_video_render_->SignalVideoFrame.connect(this,&QHMainWindow::OnRemoteVideoFrame);

    QStringList names = video_capturer_->GetVideoDeviceName();
    ui->cameraComboBox->addItems(names);

    names = audio_device_->GetPlayoutDeviceName();
    ui->playoutDeviceComboBox->addItems(names);
    names = audio_device_->GetRecordingDeviceName();
    ui->recordingDeviceComboBox->addItems(names);

    int vol=audio_device_->GetMicrophoneVolume();
    ui->microphoneVolumeSlider->setValue(vol);
    vol=audio_device_->GetSpeakerVolume();
    ui->speakerVolumeSlider->setValue(vol);

    ui->controlButton->setEnabled(video_capturer_->DeviceAvailable() && audio_device_->DeviceAvailable());

    frame_.reset(new Frame);
}

QHMainWindow::~QHMainWindow()
{
    delete ui;
}

void QHMainWindow::OnLocalVideoFrame(void *userData,const VideoFrame& videoFrame)
{
    QMutexLocker locker(&mutex_);

    postFrame(kLocal,userData,videoFrame);
}

void QHMainWindow::OnRemoteVideoFrame(void *userData,const VideoFrame& videoFrame)
{
    QMutexLocker locker(&mutex_);

    postFrame(kRemote,userData,videoFrame);
}

void QHMainWindow::postFrame(VideoFrameFrom frameFrom,void *userData,const VideoFrame& videoFrame)
{
    last_frame_ = videoFrame.video_frame_buffer();
    rtc::scoped_refptr<I420BufferInterface> buffer(last_frame_->ToI420());
    if (videoFrame.rotation() != kVideoRotation_0)
    {
        buffer = I420Buffer::Rotate(*buffer, videoFrame.rotation());
    }
    image_.reset(new uint8_t[buffer->width()*buffer->height()*4]);
    libyuv::I420ToARGB(buffer->DataY(), buffer->StrideY(), buffer->DataU(),
                       buffer->StrideU(), buffer->DataV(), buffer->StrideV(),
                       image_.get(),
                       buffer->width() * 4,
                       buffer->width(), buffer->height());

    frame_->frameFrom = frameFrom;
    frame_->buffer = image_.get();
    frame_->width = buffer->width();
    frame_->height = buffer->height();
    // 此处在子线程中，通过事件将数据传递到主线程.
    QHMainWindow *self = (QHMainWindow *)userData;
    QHFrameEvent::postEvent(self, frame_.get());
}

bool QHMainWindow::event(QEvent *event)
{
    if(event->type() == QEvent::Close)
    {
        peer_connection_->DisconnectFromPeer();
        peer_connection_->Logout();
    }
    else
    {
        QHFrameEvent *e = QHFrameEvent::event(event);
        if(e)
        {
            QMutexLocker locker(&mutex_);

            QImage image(e->frame()->buffer, e->frame()->width,e->frame()->height, QImage::Format_ARGB32);
            QPixmap pixmap=QPixmap::fromImage(image);
            if(e->frame()->frameFrom==kLocal)
            {
                ui->localVideoLabel->setPixmap(pixmap.scaled(ui->localVideoLabel->size(),Qt::KeepAspectRatio));
            }
            else if(e->frame()->frameFrom==kRemote)
            {
                ui->remoteVideoLabel->setPixmap(pixmap.scaled(ui->remoteVideoLabel->size(),Qt::KeepAspectRatio));
            }

            return true;
        }
    }

    return QWidget::event(event);
}

void QHMainWindow::on_cameraComboBox_currentIndexChanged(int index)
{
    if(video_capturer_->DeviceAvailable())
    {
        video_capturer_->OpenVideoCaptureDevice(index);

        QStringList resolutions = video_capturer_->GetSupportedCapability();
        ui->resolutionComboBox->clear();
        ui->resolutionComboBox->addItems(resolutions);
    }
}

void QHMainWindow::on_resolutionComboBox_currentIndexChanged(int index)
{
    if(video_capturer_->DeviceAvailable())
    {
        video_capturer_->SetCurrentCapability(index);
    }
}

void QHMainWindow::on_recordingDeviceComboBox_currentIndexChanged(int index)
{
    if(audio_device_->DeviceAvailable())
    {
        audio_device_->SetRecordingDevice(index);
        int vol=audio_device_->GetMicrophoneVolume();
        ui->microphoneVolumeSlider->setValue(vol);
    }
}

void QHMainWindow::on_playoutDeviceComboBox_currentIndexChanged(int index)
{
    if(audio_device_->DeviceAvailable())
    {
        audio_device_->SetPlayoutDevice(index);
        int vol=audio_device_->GetSpeakerVolume();
        ui->speakerVolumeSlider->setValue(vol);
    }
}

void QHMainWindow::on_microphoneVolumeSlider_valueChanged(int value)
{
    if(audio_device_->DeviceAvailable())
    {
        audio_device_->SetMicrophoneVolume(value);
    }
}

void QHMainWindow::on_speakerVolumeSlider_valueChanged(int value)
{
    if(audio_device_->DeviceAvailable())
    {
        audio_device_->SetSpeakerVolume(value);
    }
}

void QHMainWindow::on_controlButton_clicked()
{
    ui->recordingDeviceComboBox->setEnabled(false);
    ui->playoutDeviceComboBox->setEnabled(false);
    ui->cameraComboBox->setEnabled(false);
    ui->resolutionComboBox->setEnabled(false);
    ui->controlButton->setEnabled(false);

    if(!peer_connection_->IsLogined())
    {
        peer_connection_->Login(ui->serverIPLineEdit->text().toStdString(),ui->serverIPLineEdit->text().toInt());
    }
    else
    {
        // 退出服务器时应该断开和peer的连接，但断开和peer的连接不一定要退出服务器.
        peer_connection_->DisconnectFromPeer();
        peer_connection_->Logout();
    }
}

void QHMainWindow::on_peerListWidget_itemDoubleClicked(QListWidgetItem *item)
{
    int peerId=item->text().split("_").first().toInt();
    peer_connection_->ConnectToPeer(peerId);
}

void QHMainWindow::slotPeerConnected(int id,const QString &name)
{
    ui->peerListWidget->addItem(QString::number(id)+"_"+name);
}

void QHMainWindow::slotPeerDisconnected(int id)
{
   for(int i=0;i<ui->peerListWidget->count();i++)
   {
       int peerId=ui->peerListWidget->item(i)->text().split("_").first().toInt();
       if(peerId == id)
       {
           QListWidgetItem *item = ui->peerListWidget->item(i);
           ui->peerListWidget->removeItemWidget(item);
           delete item;
       }
   }
}

void QHMainWindow::slotLoginSucceed()
{
    ui->controlButton->setEnabled(true);
    ui->controlButton->setText(tr("logout"));
}

void QHMainWindow::slotLogoutSucceed()
{
    ui->recordingDeviceComboBox->setEnabled(true);
    ui->playoutDeviceComboBox->setEnabled(true);
    ui->cameraComboBox->setEnabled(true);
    ui->resolutionComboBox->setEnabled(true);
    ui->controlButton->setEnabled(true);
    ui->controlButton->setText(tr("login"));
    ui->peerListWidget->clear();
}
